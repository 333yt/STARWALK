import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const managerProfile = pgTable("manager_profile", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("星途經紀人"),
  motto: text("motto")
    .notNull()
    .default("記帳是工具，收藏是回憶，遊戲是動力，演唱會是目標！"),
  level: integer("level").notNull().default(3),
  xp: integer("xp").notNull().default(120),
  xpToNextLevel: integer("xp_to_next_level").notNull().default(200),
  starlightCoins: integer("starlight_coins").notNull().default(350),
  currentOutfit: text("current_outfit").notNull().default("hoodie_pink"),
  unlockedOutfits: text("unlocked_outfits")
    .notNull()
    .default('["hoodie_pink","idol_beret","bear_pajama"]'),
  baseSavings: integer("base_savings").notNull().default(28500),
  monthlyBudget: integer("monthly_budget").notNull().default(20000),
  theme: text("theme").notNull().default("strawberry"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const concertGoals = pgTable("concert_goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artist: text("artist").notNull(),
  venue: text("venue").notNull(),
  concertDate: text("concert_date").notNull(),
  targetAmount: integer("target_amount").notNull(),
  allocatedAmount: integer("allocated_amount").notNull().default(0),
  seatZone: text("seat_zone").notNull().default("VIP 搖滾區"),
  ticketColor: text("ticket_color").notNull().default("strawberry"),
  isPrimary: boolean("is_primary").notNull().default(false),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  type: text("type").notNull(), // 'expense' | 'income'
  groupType: text("group_type").notNull(), // 'daily' | 'idol' | 'income'
  category: text("category").notNull(),
  title: text("title").notNull(),
  amount: integer("amount").notNull(),
  sticker: text("sticker").notNull().default("sparkles"),
  note: text("note").notNull().default(""),
  mood: text("mood").notNull().default("happy"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  itemType: text("item_type").notNull(), // 'photocard' | 'album' | 'lightstick' | 'merch' | 'memory_ticket'
  title: text("title").notNull(),
  idolName: text("idol_name").notNull(),
  acquiredDate: text("acquired_date").notNull(),
  price: integer("price").notNull().default(0),
  rarity: text("rarity").notNull().default("SSR 本命神卡"),
  sticker: text("sticker").notNull().default("photocard"),
  memo: text("memo").notNull().default(""),
  colorTheme: text("color_theme").notNull().default("strawberry"),
  createdAt: timestamp("created_at").defaultNow(),
});
