import { db, pool } from "@/db";
import {
  managerProfile,
  concertGoals,
  transactions,
  collections,
} from "@/db/schema";
import { count } from "drizzle-orm";

let initialized = false;

export async function ensureTablesExist() {
  if (initialized) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS manager_profile (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL DEFAULT '星途經紀人',
      motto TEXT NOT NULL DEFAULT '記帳是工具，收藏是回憶，遊戲是動力，演唱會是目標！',
      level INTEGER NOT NULL DEFAULT 3,
      xp INTEGER NOT NULL DEFAULT 120,
      xp_to_next_level INTEGER NOT NULL DEFAULT 200,
      starlight_coins INTEGER NOT NULL DEFAULT 350,
      current_outfit TEXT NOT NULL DEFAULT 'hoodie_pink',
      unlocked_outfits TEXT NOT NULL DEFAULT '["hoodie_pink","idol_beret","bear_pajama"]',
      base_savings INTEGER NOT NULL DEFAULT 28500,
      monthly_budget INTEGER NOT NULL DEFAULT 20000,
      theme TEXT NOT NULL DEFAULT 'strawberry',
      updated_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS concert_goals (
      id SERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      artist TEXT NOT NULL,
      venue TEXT NOT NULL,
      concert_date TEXT NOT NULL,
      target_amount INTEGER NOT NULL,
      allocated_amount INTEGER NOT NULL DEFAULT 0,
      seat_zone TEXT NOT NULL DEFAULT 'VIP 搖滾區',
      ticket_color TEXT NOT NULL DEFAULT 'strawberry',
      is_primary BOOLEAN NOT NULL DEFAULT false,
      notes TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id SERIAL PRIMARY KEY,
      date TEXT NOT NULL,
      type TEXT NOT NULL,
      group_type TEXT NOT NULL,
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      amount INTEGER NOT NULL,
      sticker TEXT NOT NULL DEFAULT 'sparkles',
      note TEXT NOT NULL DEFAULT '',
      mood TEXT NOT NULL DEFAULT 'happy',
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS collections (
      id SERIAL PRIMARY KEY,
      item_type TEXT NOT NULL,
      title TEXT NOT NULL,
      idol_name TEXT NOT NULL,
      acquired_date TEXT NOT NULL,
      price INTEGER NOT NULL DEFAULT 0,
      rarity TEXT NOT NULL DEFAULT 'SSR 本命神卡',
      sticker TEXT NOT NULL DEFAULT 'photocard',
      memo TEXT NOT NULL DEFAULT '',
      color_theme TEXT NOT NULL DEFAULT 'strawberry',
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
  initialized = true;
}

export async function seedRichDemoData() {
  await ensureTablesExist();

  await pool.query(`TRUNCATE TABLE manager_profile, concert_goals, transactions, collections RESTART IDENTITY;`);

  await db.insert(managerProfile).values({
    name: "星途經紀人・小星",
    motto: "記帳是工具，收藏是回憶，遊戲是動力，演唱會是目標！",
    level: 4,
    xp: 145,
    xpToNextLevel: 200,
    starlightCoins: 520,
    currentOutfit: "hoodie_pink",
    unlockedOutfits: JSON.stringify([
      "hoodie_pink",
      "starlight_cape",
      "y2k_headphone",
      "bear_pajama",
      "royal_uniform",
    ]),
    baseSavings: 32000,
    monthlyBudget: 20000,
    theme: "strawberry",
  });

  await db.insert(concertGoals).values([
    {
      title: "2026 STARLIGHT 台北小巨蛋世界巡迴《銀河漫步》",
      artist: "LUNA & STARLIGHT",
      venue: "台北小巨蛋 Taipei Arena",
      concertDate: "2026-12-20",
      targetAmount: 12000,
      allocatedAmount: 8400,
      seatZone: "VIP 特A搖滾區 第一排",
      ticketColor: "strawberry",
      isPrimary: true,
      notes: "門票 NT$ 6,800 + 二代手燈 NT$ 1,800 + 應援痛包與周邊預算 NT$ 3,400 ✨",
    },
    {
      title: "2027 首爾安可場三天兩夜追星自由行",
      artist: "LUNA & STARLIGHT",
      venue: "首爾 KSPO DOME",
      concertDate: "2027-03-15",
      targetAmount: 35000,
      allocatedAmount: 6500,
      seatZone: "FLOOR 延伸舞台旁",
      ticketColor: "lavender",
      isPrimary: false,
      notes: "機票 + 弘大住宿 + 首爾安可場門票基金 ✈️",
    },
  ]);

  await db.insert(transactions).values([
    // 2026-11-01
    {
      date: "2026-11-01",
      type: "income",
      groupType: "income",
      category: "薪資零用錢",
      title: "11月經紀人薪水與打工獎金入帳",
      amount: 18000,
      sticker: "coin",
      note: "本月也要努力存錢看小巨蛋第一排！💪",
      mood: "excited",
    },
    {
      date: "2026-11-01",
      type: "expense",
      groupType: "daily",
      category: "餐飲美食",
      title: "草莓奶油舒芙蕾鬆餅下午茶",
      amount: 320,
      sticker: "cake",
      note: "跟追星閨蜜一起去咖啡廳擺拍小卡 🍓",
      mood: "happy",
    },
    // 2026-11-02
    {
      date: "2026-11-02",
      type: "expense",
      groupType: "idol",
      category: "專輯小卡",
      title: "正規三輯《STAR WALK》通路特典專 x2",
      amount: 1180,
      sticker: "album",
      note: "抽中本命眨眼特典卡！手氣太好了嗚嗚 😭💖",
      mood: "blessed",
    },
    {
      date: "2026-11-02",
      type: "expense",
      groupType: "daily",
      category: "交通通勤",
      title: "捷運定期票加值",
      amount: 1200,
      sticker: "train",
      note: "每月固定通勤支出",
      mood: "happy",
    },
    // 2026-11-03
    {
      date: "2026-11-03",
      type: "expense",
      groupType: "daily",
      category: "手搖飲甜點",
      title: "黑糖珍珠鮮奶微糖少冰",
      amount: 75,
      sticker: "boba",
      note: "上班補充糖分 ✨",
      mood: "happy",
    },
    // 2026-11-04 (Default date shown in user screenshot!)
    {
      date: "2026-11-04",
      type: "expense",
      groupType: "idol",
      category: "官方周邊",
      title: "二代星光手燈蝴蝶結緞帶＆毛絨卡套",
      amount: 650,
      sticker: "lightstick",
      note: "為 12 月演唱會提前打扮手燈！超可愛手繪兔耳款 🐰",
      mood: "excited",
    },
    {
      date: "2026-11-04",
      type: "expense",
      groupType: "daily",
      category: "餐飲美食",
      title: "日式起司漢堡排定食便當",
      amount: 210,
      sticker: "bento",
      note: "午餐吃飽飽才有力氣搶票",
      mood: "happy",
    },
    {
      date: "2026-11-04",
      type: "income",
      groupType: "income",
      category: "二手回血",
      title: "出清重複專卡回血入帳",
      amount: 450,
      sticker: "photocard",
      note: "把重複的專卡讓給需要的粉絲，回血轉入演唱會基金！",
      mood: "blessed",
    },
    // 2026-11-07
    {
      date: "2026-11-07",
      type: "expense",
      groupType: "idol",
      category: "應援集資",
      title: "本命生日捷運燈箱與咖啡廳應援集資",
      amount: 500,
      sticker: "heart",
      note: "期待生日週去打卡領取應援杯套 🎂",
      mood: "blessed",
    },
    // 2026-11-10
    {
      date: "2026-11-10",
      type: "expense",
      groupType: "daily",
      category: "日用購物",
      title: "手帳紙膠帶與九宮格活頁卡冊補充頁",
      amount: 290,
      sticker: "sparkles",
      note: "把新收到的小卡通通收進冊子裡！",
      mood: "happy",
    },
    // 2026-11-14
    {
      date: "2026-11-14",
      type: "expense",
      groupType: "idol",
      category: "演唱會門票",
      title: "預留小巨蛋周邊快閃店排隊購物金",
      amount: 1500,
      sticker: "ticket",
      note: "快閃店限定毛巾跟隨機卡包必買清單",
      mood: "excited",
    },
    // 2026-11-18
    {
      date: "2026-11-18",
      type: "expense",
      groupType: "daily",
      category: "餐飲美食",
      title: "韓式炸雞與辣炒年糕聚餐",
      amount: 480,
      sticker: "bento",
      note: "看回歸舞台直播配炸雞最幸福！🍗",
      mood: "excited",
    },
  ]);

  await db.insert(collections).values([
    {
      itemType: "photocard",
      title: "《STAR WALK》粉紅兔耳比心特典小卡",
      idolName: "LUNA 露娜",
      acquiredDate: "2026-11-02",
      price: 590,
      rarity: "SSR 本命神卡",
      sticker: "photocard",
      memo: "親手從未拆專抽中！閃膜是星星圖案超夢幻 ✨",
      colorTheme: "strawberry",
    },
    {
      itemType: "lightstick",
      title: "官方二代星光魔杖手燈 Ver.2",
      idolName: "STARLIGHT 全員",
      acquiredDate: "2026-10-15",
      price: 1850,
      rarity: "限定收藏",
      sticker: "lightstick",
      memo: "已經綁定藍牙中控，貼上了手繪草莓貼紙！",
      colorTheme: "lavender",
    },
    {
      itemType: "album",
      title: "正規三輯《STAR WALK》精裝手帳版",
      idolName: "STARLIGHT 全員",
      acquiredDate: "2026-11-02",
      price: 680,
      rarity: "SR 特典閃卡",
      sticker: "album",
      memo: "內附 80 頁手繪歌詞本與成員手寫貼紙包 💿",
      colorTheme: "butter",
    },
    {
      itemType: "memory_ticket",
      title: "2026 夏日粉絲見面會《First Star》票根",
      idolName: "LUNA & STARLIGHT",
      acquiredDate: "2026-07-18",
      price: 4800,
      rarity: "SSR 本命神卡",
      sticker: "ticket",
      memo: "第一次在現場聽到安可曲大合唱，接到了掉下來的星星彩帶！🌟",
      colorTheme: "mint",
    },
  ]);
}

export async function seedZeroScreenshotMode() {
  await ensureTablesExist();
  await pool.query(`TRUNCATE TABLE manager_profile, concert_goals, transactions, collections RESTART IDENTITY;`);

  await db.insert(managerProfile).values({
    name: "星途經紀人",
    motto: "記帳是工具，收藏是回憶，遊戲是動力，演唱會是目標！",
    level: 1,
    xp: 0,
    xpToNextLevel: 50,
    starlightCoins: 100,
    currentOutfit: "hoodie_pink",
    unlockedOutfits: JSON.stringify(["hoodie_pink"]),
    baseSavings: 0,
    monthlyBudget: 20000,
    theme: "strawberry",
  });
}

export async function ensureSeeded() {
  await ensureTablesExist();
  const existing = await db.select({ value: count() }).from(managerProfile);
  if ((existing[0]?.value ?? 0) === 0) {
    await seedRichDemoData();
  }
}
