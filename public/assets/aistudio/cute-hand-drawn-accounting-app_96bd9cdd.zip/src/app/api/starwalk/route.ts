import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  managerProfile,
  concertGoals,
  transactions,
  collections,
} from "@/db/schema";
import {
  ensureSeeded,
  seedRichDemoData,
  seedZeroScreenshotMode,
} from "@/db/seed";
import { desc, eq } from "drizzle-orm";

async function awardXpAndCoins(xpGain: number, coinGain: number) {
  const profiles = await db.select().from(managerProfile);
  if (profiles.length === 0) return;
  const p = profiles[0];
  let newXp = p.xp + xpGain;
  let newLevel = p.level;
  let nextXp = p.xpToNextLevel;

  while (newXp >= nextXp) {
    newXp -= nextXp;
    newLevel += 1;
    nextXp = Math.round(nextXp * 1.25);
  }

  await db
    .update(managerProfile)
    .set({
      level: newLevel,
      xp: newXp,
      xpToNextLevel: nextXp,
      starlightCoins: p.starlightCoins + coinGain,
      updatedAt: new Date(),
    })
    .where(eq(managerProfile.id, p.id));
}

async function getFullState() {
  await ensureSeeded();

  const profiles = await db.select().from(managerProfile);
  const profile = profiles[0];

  const goals = await db
    .select()
    .from(concertGoals)
    .orderBy(desc(concertGoals.isPrimary), desc(concertGoals.id));

  const txList = await db
    .select()
    .from(transactions)
    .orderBy(desc(transactions.date), desc(transactions.id));

  const colList = await db
    .select()
    .from(collections)
    .orderBy(desc(collections.acquiredDate), desc(collections.id));

  return {
    profile,
    concertGoals: goals,
    transactions: txList,
    collections: colList,
  };
}

export async function GET() {
  try {
    const state = await getFullState();
    return NextResponse.json(state);
  } catch (error) {
    console.error("GET /api/starwalk error:", error);
    return NextResponse.json(
      { error: "無法載入星途記帳資料" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();
    const { action } = body;

    if (action === "add_transaction") {
      const {
        date,
        type,
        groupType,
        category,
        title,
        amount,
        sticker,
        note,
        mood,
      } = body;

      await db.insert(transactions).values({
        date: date || "2026-11-04",
        type: type || "expense",
        groupType: groupType || (type === "income" ? "income" : "daily"),
        category: category || "餐飲美食",
        title: title || "未命名帳目",
        amount: Math.max(0, Number(amount) || 0),
        sticker: sticker || "sparkles",
        note: note || "",
        mood: mood || "happy",
      });

      await awardXpAndCoins(15, 25);
    } else if (action === "delete_transaction") {
      const { id } = body;
      if (id) {
        await db.delete(transactions).where(eq(transactions.id, Number(id)));
      }
    } else if (action === "add_concert_goal") {
      const {
        title,
        artist,
        venue,
        concertDate,
        targetAmount,
        allocatedAmount,
        seatZone,
        ticketColor,
        isPrimary,
        notes,
      } = body;

      if (isPrimary) {
        await db.update(concertGoals).set({ isPrimary: false });
      }

      await db.insert(concertGoals).values({
        title: title || "未命名演唱會目標",
        artist: artist || "本命偶像",
        venue: venue || "台北小巨蛋",
        concertDate: concertDate || "2026-12-20",
        targetAmount: Math.max(100, Number(targetAmount) || 10000),
        allocatedAmount: Math.max(0, Number(allocatedAmount) || 0),
        seatZone: seatZone || "VIP 搖滾區",
        ticketColor: ticketColor || "strawberry",
        isPrimary: Boolean(isPrimary),
        notes: notes || "",
      });

      await awardXpAndCoins(30, 50);
    } else if (action === "allocate_concert_fund") {
      const { goalId, addAmount } = body;
      const existing = await db
        .select()
        .from(concertGoals)
        .where(eq(concertGoals.id, Number(goalId)));

      if (existing.length > 0) {
        const goal = existing[0];
        const newAllocated = Math.max(
          0,
          goal.allocatedAmount + (Number(addAmount) || 0)
        );
        await db
          .update(concertGoals)
          .set({ allocatedAmount: newAllocated })
          .where(eq(concertGoals.id, goal.id));
        await awardXpAndCoins(25, 35);
      }
    } else if (action === "set_primary_concert") {
      const { goalId } = body;
      await db.update(concertGoals).set({ isPrimary: false });
      await db
        .update(concertGoals)
        .set({ isPrimary: true })
        .where(eq(concertGoals.id, Number(goalId)));
    } else if (action === "delete_concert_goal") {
      const { goalId } = body;
      await db
        .delete(concertGoals)
        .where(eq(concertGoals.id, Number(goalId)));
    } else if (action === "update_budget") {
      const { monthlyBudget, baseSavings } = body;
      const profiles = await db.select().from(managerProfile);
      if (profiles.length > 0) {
        const p = profiles[0];
        await db
          .update(managerProfile)
          .set({
            monthlyBudget:
              monthlyBudget !== undefined
                ? Math.max(0, Number(monthlyBudget))
                : p.monthlyBudget,
            baseSavings:
              baseSavings !== undefined
                ? Math.max(0, Number(baseSavings))
                : p.baseSavings,
            updatedAt: new Date(),
          })
          .where(eq(managerProfile.id, p.id));
      }
    } else if (action === "update_profile") {
      const { name, motto, currentOutfit, unlockOutfitId, unlockCost, theme } =
        body;
      const profiles = await db.select().from(managerProfile);
      if (profiles.length > 0) {
        const p = profiles[0];
        let unlocked: string[] = [];
        try {
          unlocked = JSON.parse(p.unlockedOutfits);
        } catch {
          unlocked = ["hoodie_pink"];
        }

        let newCoins = p.starlightCoins;
        let nextOutfit = currentOutfit ?? p.currentOutfit;

        if (unlockOutfitId && !unlocked.includes(unlockOutfitId)) {
          const cost = Number(unlockCost) || 100;
          if (newCoins >= cost) {
            newCoins -= cost;
            unlocked.push(unlockOutfitId);
            nextOutfit = unlockOutfitId;
          }
        }

        await db
          .update(managerProfile)
          .set({
            name: name ?? p.name,
            motto: motto ?? p.motto,
            currentOutfit: nextOutfit,
            unlockedOutfits: JSON.stringify(unlocked),
            starlightCoins: newCoins,
            theme: theme ?? p.theme,
            updatedAt: new Date(),
          })
          .where(eq(managerProfile.id, p.id));
      }
    } else if (action === "claim_quest") {
      const { xpReward, coinReward } = body;
      await awardXpAndCoins(Number(xpReward) || 25, Number(coinReward) || 40);
    } else if (action === "add_collection") {
      const {
        itemType,
        title,
        idolName,
        acquiredDate,
        price,
        rarity,
        sticker,
        memo,
        colorTheme,
      } = body;
      await db.insert(collections).values({
        itemType: itemType || "photocard",
        title: title || "未命名收藏",
        idolName: idolName || "LUNA",
        acquiredDate: acquiredDate || "2026-11-04",
        price: Math.max(0, Number(price) || 0),
        rarity: rarity || "SSR 本命神卡",
        sticker: sticker || "photocard",
        memo: memo || "",
        colorTheme: colorTheme || "strawberry",
      });
      await awardXpAndCoins(20, 30);
    } else if (action === "delete_collection") {
      const { id } = body;
      await db.delete(collections).where(eq(collections.id, Number(id)));
    } else if (action === "reset_demo") {
      await seedRichDemoData();
    } else if (action === "reset_zero") {
      await seedZeroScreenshotMode();
    }

    const updatedState = await getFullState();
    return NextResponse.json(updatedState);
  } catch (error) {
    console.error("POST /api/starwalk error:", error);
    return NextResponse.json(
      { error: "執行星途操作時發生錯誤" },
      { status: 500 }
    );
  }
}
