import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "STAR WALK 星途手帳｜追星旅程與生活養成・可愛手繪記帳 App",
  description:
    "追星旅程與生活養成・記帳是工具，演唱會是目標！結合手繪貼紙月曆記帳、演唱會存錢票根、角色換裝養成與本命小卡收藏冊。",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-Hant">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Noto+Sans+TC:wght@400;500;700;900&family=Space+Mono:wght@700&family=Zen+Maru+Gothic:wght@500;700;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="journal-paper-bg text-[#4A3728] antialiased selection:bg-[#FFE3EC] selection:text-[#FF5C8A]">
        {children}
      </body>
    </html>
  );
}
