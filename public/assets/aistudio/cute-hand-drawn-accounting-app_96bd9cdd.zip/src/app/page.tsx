"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  ChibiManagerAvatar,
  HandDrawnSticker,
  OUTFIT_CATALOG,
  playKawaiiSound,
} from "@/components/KawaiiIllustrations";
import {
  QuickRecordModal,
  ConcertGoalModal,
  BudgetSettingsModal,
} from "@/components/StarWalkModals";
import {
  ConcertJourneyTab,
  AnalyticsTab,
  CollectionBookTab,
  CharacterQuestsTab,
  MemoryHallTab,
  ConcertGoalItem,
  TransactionItem,
  CollectionItem,
  ManagerProfileData,
} from "@/components/SecondaryTabsView";
import {
  Plus,
  Zap,
  Palette,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Compass,
  Trash2,
  Sparkles,
  Calendar as CalendarIcon,
  ListFilter,
  CheckCircle2,
  RotateCcw,
  HeartHandshake,
} from "lucide-react";

type TabId =
  | "home"
  | "concert"
  | "ledger"
  | "analytics"
  | "collection"
  | "character"
  | "memory";

const NAV_TABS: { id: TabId; emoji: string; label: string }[] = [
  { id: "home", emoji: "🏠", label: "星途首頁" },
  { id: "concert", emoji: "🎫", label: "演唱會旅程" },
  { id: "ledger", emoji: "📅", label: "追星記帳" },
  { id: "analytics", emoji: "📊", label: "財務分析" },
  { id: "collection", emoji: "💖", label: "追星收藏冊" },
  { id: "character", emoji: "🎮", label: "角色與任務" },
  { id: "memory", emoji: "🎟️", label: "星途回憶館" },
];

const THEME_CLASSES: Record<string, { label: string; bodyClass: string; badgeBg: string }> = {
  strawberry: {
    label: "🍓 草莓牛奶手帳",
    bodyClass: "journal-paper-bg",
    badgeBg: "#FFE3EC",
  },
  mint: {
    label: "🌿 薄荷蘇打手帳",
    bodyClass: "theme-mint-bg",
    badgeBg: "#E0FAF0",
  },
  lilac: {
    label: "💜 紫丁香星光",
    bodyClass: "theme-lilac-bg",
    badgeBg: "#EFE6FF",
  },
  butter: {
    label: "🧈 奶油焦糖手帳",
    bodyClass: "theme-butter-bg",
    badgeBg: "#FFF3C4",
  },
};

export default function StarWalkApp() {
  const [activeTab, setActiveTab] = useState<TabId>("home");
  const [ledgerViewMode, setLedgerViewMode] = useState<"calendar" | "list">(
    "calendar"
  );
  const [listFilterGroup, setListFilterGroup] = useState<
    "all" | "idol" | "daily" | "income"
  >("all");

  // Calendar state defaulted to 2026-11-04 (matching user screenshot!)
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(11); // 1-12
  const [selectedDate, setSelectedDate] = useState("2026-11-04");

  // App state from PostgreSQL API
  const [profile, setProfile] = useState<ManagerProfileData>({
    id: 1,
    name: "星途經紀人・小星",
    motto: "記帳是工具，收藏是回憶，遊戲是動力，演唱會是目標！",
    level: 4,
    xp: 145,
    xpToNextLevel: 200,
    starlightCoins: 520,
    currentOutfit: "hoodie_pink",
    unlockedOutfits: '["hoodie_pink","starlight_cape","y2k_headphone"]',
    baseSavings: 32000,
    monthlyBudget: 20000,
    theme: "strawberry",
  });
  const [concertGoals, setConcertGoals] = useState<ConcertGoalItem[]>([]);
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [collections, setCollections] = useState<CollectionItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Interactive UI controls
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [previewEmptyConcert, setPreviewEmptyConcert] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals
  const [isQuickRecordOpen, setIsQuickRecordOpen] = useState(false);
  const [isConcertModalOpen, setIsConcertModalOpen] = useState(false);
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch("/api/starwalk");
      if (!res.ok) return;
      const data = await res.json();
      if (data.profile) setProfile(data.profile);
      if (data.concertGoals) setConcertGoals(data.concertGoals);
      if (data.transactions) setTransactions(data.transactions);
      if (data.collections) setCollections(data.collections);
    } catch (e) {
      console.error("Failed to fetch state:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const postAction = async (payload: Record<string, unknown>) => {
    const res = await fetch("/api/starwalk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.profile) setProfile(data.profile);
      if (data.concertGoals) setConcertGoals(data.concertGoals);
      if (data.transactions) setTransactions(data.transactions);
      if (data.collections) setCollections(data.collections);
    }
  };

  // Financial Metrics Calculation
  const metrics = useMemo(() => {
    const totalIncome = transactions
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = transactions
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    const totalLiquidFunds = Math.max(
      0,
      (profile.baseSavings || 0) + totalIncome - totalExpense
    );

    const allocatedConcertFund = concertGoals.reduce(
      (sum, g) => sum + (g.allocatedAmount || 0),
      0
    );

    const availableUnallocated = Math.max(
      0,
      totalLiquidFunds - allocatedConcertFund
    );

    // Monthly expenses for active calendar month (e.g. 2026-11)
    const monthPrefix = `${currentYear}-${String(currentMonth).padStart(
      2,
      "0"
    )}`;
    const monthTxs = transactions.filter((t) => t.date.startsWith(monthPrefix));

    const monthDailyExpense = monthTxs
      .filter((t) => t.type === "expense" && t.groupType === "daily")
      .reduce((sum, t) => sum + t.amount, 0);

    const monthIdolExpense = monthTxs
      .filter((t) => t.type === "expense" && t.groupType === "idol")
      .reduce((sum, t) => sum + t.amount, 0);

    const monthTotalExpense = monthDailyExpense + monthIdolExpense;
    const monthTotalIncome = monthTxs
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);

    const monthlyRemainingBudget = Math.max(
      0,
      (profile.monthlyBudget || 20000) - monthTotalExpense
    );

    const budgetUsedPct = Math.min(
      100,
      Math.round(
        (monthTotalExpense / Math.max(1, profile.monthlyBudget || 20000)) * 100
      )
    );

    return {
      totalLiquidFunds,
      allocatedConcertFund,
      availableUnallocated,
      monthDailyExpense,
      monthIdolExpense,
      monthTotalExpense,
      monthTotalIncome,
      monthlyRemainingBudget,
      budgetUsedPct,
    };
  }, [transactions, concertGoals, profile, currentYear, currentMonth]);

  // Calendar Cells Generator (Monday-first grid matching screenshot!)
  const calendarCells = useMemo(() => {
    const firstDayOfMonth = new Date(currentYear, currentMonth - 1, 1);
    const daysInMonth = new Date(currentYear, currentMonth, 0).getDate();
    const daysInPrevMonth = new Date(
      currentYear,
      currentMonth - 1,
      0
    ).getDate();

    // Convert JS getDay() (0=Sun..6=Sat) to Monday-first (0=Mon..6=Sun)
    const startOffset = (firstDayOfMonth.getDay() + 6) % 7;

    const cells: {
      day: number;
      dateStr: string;
      isCurrentMonth: boolean;
      isWeekend: boolean;
    }[] = [];

    // Previous month trailing days
    for (let i = startOffset - 1; i >= 0; i--) {
      const d = daysInPrevMonth - i;
      const prevM = currentMonth === 1 ? 12 : currentMonth - 1;
      const prevY = currentMonth === 1 ? currentYear - 1 : currentYear;
      const dateStr = `${prevY}-${String(prevM).padStart(2, "0")}-${String(
        d
      ).padStart(2, "0")}`;
      const idx = cells.length;
      cells.push({
        day: d,
        dateStr,
        isCurrentMonth: false,
        isWeekend: idx % 7 === 5 || idx % 7 === 6,
      });
    }

    // Current month days
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${currentYear}-${String(currentMonth).padStart(
        2,
        "0"
      )}-${String(d).padStart(2, "0")}`;
      const idx = cells.length;
      cells.push({
        day: d,
        dateStr,
        isCurrentMonth: true,
        isWeekend: idx % 7 === 5 || idx % 7 === 6,
      });
    }

    // Next month leading days to fill complete rows of 7
    const totalNeeded = cells.length <= 35 ? 35 : 42;
    let nextD = 1;
    while (cells.length < totalNeeded) {
      const nextM = currentMonth === 12 ? 1 : currentMonth + 1;
      const nextY = currentMonth === 12 ? currentYear + 1 : currentYear;
      const dateStr = `${nextY}-${String(nextM).padStart(2, "0")}-${String(
        nextD
      ).padStart(2, "0")}`;
      const idx = cells.length;
      cells.push({
        day: nextD,
        dateStr,
        isCurrentMonth: false,
        isWeekend: idx % 7 === 5 || idx % 7 === 6,
      });
      nextD++;
    }

    return cells;
  }, [currentYear, currentMonth]);

  // Transactions for the selected date (e.g. 2026-11-04)
  const selectedDateTransactions = useMemo(
    () => transactions.filter((t) => t.date === selectedDate),
    [transactions, selectedDate]
  );

  const selectedDateExpense = useMemo(
    () =>
      selectedDateTransactions
        .filter((t) => t.type === "expense")
        .reduce((s, t) => s + t.amount, 0),
    [selectedDateTransactions]
  );

  const selectedDateIncome = useMemo(
    () =>
      selectedDateTransactions
        .filter((t) => t.type === "income")
        .reduce((s, t) => s + t.amount, 0),
    [selectedDateTransactions]
  );

  const primaryGoal = useMemo(
    () => concertGoals.find((g) => g.isPrimary) || concertGoals[0] || null,
    [concertGoals]
  );

  const currentOutfitMeta =
    OUTFIT_CATALOG.find((o) => o.id === profile.currentOutfit) ||
    OUTFIT_CATALOG[0];

  const activeTheme =
    THEME_CLASSES[profile.theme] || THEME_CLASSES.strawberry;

  const handleCycleTheme = async () => {
    playKawaiiSound("click", soundEnabled);
    const keys = Object.keys(THEME_CLASSES);
    const nextIdx = (keys.indexOf(profile.theme) + 1) % keys.length;
    const nextTheme = keys[nextIdx];
    await postAction({ action: "update_profile", theme: nextTheme });
    showToast(`已切換手帳紙主題：${THEME_CLASSES[nextTheme].label} ✨`);
  };

  const handleCycleOutfitQuick = async () => {
    playKawaiiSound("stamp", soundEnabled);
    let unlocked: string[] = ["hoodie_pink"];
    try {
      unlocked = JSON.parse(profile.unlockedOutfits);
    } catch {
      unlocked = ["hoodie_pink"];
    }
    const list = unlocked.length > 0 ? unlocked : ["hoodie_pink"];
    const nextIdx = (list.indexOf(profile.currentOutfit) + 1) % list.length;
    const nextOutfit = list[nextIdx];
    await postAction({ action: "update_profile", currentOutfit: nextOutfit });
    const meta = OUTFIT_CATALOG.find((o) => o.id === nextOutfit);
    showToast(`👗 已換上穿搭：${meta?.name || "粉嫩帽T練舞服"}！`);
  };

  const handlePrevMonth = () => {
    playKawaiiSound("click", soundEnabled);
    if (currentMonth === 1) {
      setCurrentYear((y) => y - 1);
      setCurrentMonth(12);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    playKawaiiSound("click", soundEnabled);
    if (currentMonth === 12) {
      setCurrentYear((y) => y + 1);
      setCurrentMonth(1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const xpPercentage = Math.min(
    100,
    Math.round((profile.xp / Math.max(1, profile.xpToNextLevel)) * 100)
  );

  return (
    <div
      className={`min-h-screen pb-16 transition-colors duration-300 ${activeTheme.bodyClass}`}
    >
      {/* Floating Kawaii Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 sketch-card bg-[#FFF3B0] px-5 py-3 flex items-center gap-2.5 animate-stamp">
          <Sparkles className="w-5 h-5 text-[#FF5C8A] shrink-0" />
          <span className="text-sm font-black text-[#4A3728]">
            {toastMessage}
          </span>
        </div>
      )}

      {/* ==================== TOP UTILITY HEADER BAR ==================== */}
      <header className="sticky top-0 z-30 bg-[#FFFDF7]/92 backdrop-blur-md border-b-[2.5px] border-[#4A3728]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Left: Hand-drawn Logo & Title */}
          <div
            onClick={() => {
              playKawaiiSound("click", soundEnabled);
              setActiveTab("home");
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#FF6B9D] via-[#C86BFF] to-[#9B6BFF] border-[2.5px] border-[#4A3728] shadow-[3px_3px_0px_#4A3728] flex items-center justify-center group-hover:rotate-6 transition-transform">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-wider text-[#4A3728]">
                  STAR WALK
                </span>
                <span className="hidden sm:inline-block text-[11px] font-black px-2 py-0.5 rounded-full bg-[#FFE3EC] text-[#FF5C8A] border border-[#4A3728]">
                  手繪星途手帳
                </span>
              </div>
              <p className="text-xs font-bold text-[#8C7365]">
                追星旅程與生活養成・記帳是工具，演唱會是目標
              </p>
            </div>
          </div>

          {/* Right: Financial Pills & Kawaii Controls */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-2.5">
            {/* Total Liquid Funds Pill */}
            <button
              onClick={() => {
                playKawaiiSound("click", soundEnabled);
                setIsBudgetModalOpen(true);
              }}
              className="sticker-btn-soft px-3.5 py-1.5 rounded-2xl bg-[#F3F6FA] text-left flex flex-col"
              title="點擊調整金庫與預算"
            >
              <span className="text-[11px] font-bold text-[#8C7365] leading-tight">
                總流動資金
              </span>
              <span className="font-mono-num text-sm font-black text-[#4A3728]">
                NT$ {metrics.totalLiquidFunds.toLocaleString()}
              </span>
            </button>

            {/* Available Unallocated Funds Pill */}
            <button
              onClick={() => {
                playKawaiiSound("click", soundEnabled);
                setIsBudgetModalOpen(true);
              }}
              className="sticker-btn-soft px-3.5 py-1.5 rounded-2xl bg-[#FFF0F6] text-left flex flex-col"
              title="扣除演唱會專款後可自由分配的資金"
            >
              <span className="text-[11px] font-bold text-[#FF5C8A] leading-tight">
                可用未分配資金
              </span>
              <span className="font-mono-num text-sm font-black text-[#FF5C8A]">
                NT$ {metrics.availableUnallocated.toLocaleString()}
              </span>
            </button>

            {/* Primary CTA: Quick Record */}
            <button
              onClick={() => {
                playKawaiiSound("stamp", soundEnabled);
                setIsQuickRecordOpen(true);
              }}
              className="sticker-btn px-4 py-2.5 rounded-full bg-gradient-to-r from-[#FF4785] to-[#B833FF] text-white text-xs sm:text-sm font-black flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <Zap className="w-3.5 h-3.5 fill-[#FFD84D] text-[#FFD84D]" />
              <span>快速記帳</span>
            </button>

            {/* Theme Palette Switcher */}
            <button
              onClick={handleCycleTheme}
              className="sticker-btn-soft px-3 py-2 rounded-full bg-white flex items-center gap-1 text-xs font-black text-[#4A3728]"
              title="切換手帳紙配色主題"
            >
              <Palette className="w-4 h-4 text-[#FF5C8A]" />
              <span className="hidden md:inline">✨ 主題</span>
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                if (next) playKawaiiSound("coin", true);
                showToast(
                  next ? "🔊 已開啟可愛手繪音效！" : "🔇 已切換為靜音模式"
                );
              }}
              className={`sticker-btn-soft w-9 h-9 rounded-full flex items-center justify-center ${
                soundEnabled ? "bg-[#FFE3EC] text-[#FF5C8A]" : "bg-white text-[#8C7365]"
              }`}
              title="切換音效"
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            {/* Database Sync Status / Demo Mode Switcher */}
            <button
              onClick={() => {
                playKawaiiSound("click", soundEnabled);
                setIsBudgetModalOpen(true);
              }}
              className="sticker-btn-soft px-3 py-2 rounded-full bg-[#E4FBF0] text-[#1E8E68] text-xs font-black flex items-center gap-1.5"
              title="金庫設定與範例資料切換"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">手帳同步中</span>
              <span className="xl:hidden">設定</span>
            </button>
          </div>
        </div>

        {/* ==================== 7 WASHI BOOKMARK NAVIGATION TABS ==================== */}
        <div className="border-t-2 border-dashed border-[#E6D7C3] bg-[#FFF9EE]/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center gap-2 overflow-x-auto no-scrollbar">
            {NAV_TABS.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    playKawaiiSound("click", soundEnabled);
                    setActiveTab(tab.id);
                  }}
                  className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-black flex items-center gap-2 shrink-0 transition-all cursor-pointer ${
                    isActive
                      ? "bg-[#FFE3EC] text-[#FF3B75] border-2 border-[#4A3728] shadow-[3px_3px_0px_#4A3728] -translate-y-0.5"
                      : "bg-white/80 text-[#4A3728] border-2 border-transparent hover:border-[#D8C2B0] hover:bg-white"
                  }`}
                >
                  <span className="text-base">{tab.emoji}</span>
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* ==================== MAIN CONTENT CONTAINER ==================== */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 space-y-6">
        {loading ? (
          <div className="sketch-card bg-white p-12 text-center space-y-3">
            <div className="text-2xl animate-bounce">🍓✨</div>
            <div className="text-base font-black text-[#4A3728]">
              正在翻開你的星途手繪記帳本...
            </div>
          </div>
        ) : activeTab === "home" ? (
          /* =====================================================================
             TAB 1: 🏠 星途首頁 (HOME DASHBOARD — SCREENSHOT 2 REDESIGN)
             ===================================================================== */
          <div className="space-y-6">
            {/* HERO MANAGER GREETING POSTCARD */}
            <section className="sketch-card relative overflow-hidden bg-gradient-to-r from-[#FFE8F2] via-[#FFF6EB] to-[#F3E8FF] p-6 md:p-7">
              {/* Decorative Washi Tapes */}
              <div
                className="washi-tape-yellow absolute -top-3 left-16 w-28 h-5 rounded-sm"
                style={{ transform: "rotate(-2deg)" }}
              />
              <div
                className="washi-tape-mint absolute -top-3 right-20 w-24 h-5 rounded-sm hidden sm:block"
                style={{ transform: "rotate(3deg)" }}
              />

              <div className="flex flex-col lg:flex-row items-center justify-between gap-6 relative z-10">
                {/* Left + Center: Chibi Avatar & Growth Info */}
                <div className="flex flex-col sm:flex-row items-center gap-5 sm:gap-6 text-center sm:text-left">
                  {/* Custom Hand-Drawn Chibi Avatar (Click to change outfit!) */}
                  <div
                    onClick={handleCycleOutfitQuick}
                    className="cursor-pointer group relative"
                    title="點擊頭像快速切換穿搭造型！"
                  >
                    <ChibiManagerAvatar
                      outfit={profile.currentOutfit}
                      size={122}
                      level={profile.level}
                    />
                    <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-black text-[#8C7365] opacity-0 group-hover:opacity-100 transition-opacity">
                      👆 點擊換裝
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {/* Top Pills: Outfit Name + Starlight Coins */}
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                      <button
                        onClick={handleCycleOutfitQuick}
                        className="px-3 py-1 rounded-full bg-[#FFD6E6] border-2 border-[#4A3728] text-xs font-black text-[#D9386A] shadow-[2px_2px_0px_#4A3728] cursor-pointer hover:bg-[#FFC2DA]"
                      >
                        👗 {currentOutfitMeta.name}
                      </button>
                      <span className="px-3 py-1 rounded-full bg-[#FFF5CC] border-2 border-[#4A3728] text-xs font-black text-[#4A3728] shadow-[2px_2px_0px_#4A3728]">
                        ✨ 經紀星光幣：
                        <strong className="font-mono-num text-[#E58A1F]">
                          {profile.starlightCoins} P
                        </strong>
                      </span>
                    </div>

                    {/* Greeting Headline */}
                    <h1 className="text-2xl sm:text-3xl font-black text-[#4A3728] tracking-tight flex items-center justify-center sm:justify-start gap-2">
                      <span>早安，{profile.name}！💖</span>
                    </h1>

                    {/* Motto */}
                    <p className="text-sm sm:text-base font-bold text-[#6E5646]">
                      {profile.motto}
                    </p>

                    {/* XP Crayon Progress Bar */}
                    <div className="pt-1 max-w-md mx-auto sm:mx-0">
                      <div className="flex items-center justify-between text-xs font-black text-[#6E5646] mb-1">
                        <span>角色成長經驗值 (XP)</span>
                        <span className="font-mono-num text-[#4A3728]">
                          {profile.xp} / {profile.xpToNextLevel} XP (
                          {xpPercentage}%)
                        </span>
                      </div>
                      <div className="w-full h-4 rounded-full bg-white border-2 border-[#4A3728] overflow-hidden p-0.5 shadow-inner">
                        <div
                          className="h-full rounded-full crayon-stripe-pink transition-all duration-500"
                          style={{ width: `${ Math.max(8, xpPercentage) }%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right: Today's Stamp Status & Quick Record CTA */}
                <div className="flex flex-col items-center lg:items-end gap-3 shrink-0">
                  <div
                    onClick={() => {
                      playKawaiiSound("click", soundEnabled);
                      setActiveTab("ledger");
                    }}
                    className="px-4 py-2 rounded-full bg-[#FFF3CD] border-2 border-[#4A3728] shadow-[2.5px_2.5px_0px_#4A3728] text-xs font-black text-[#B86E14] flex items-center gap-1.5 cursor-pointer hover:bg-[#FFEAA7]"
                  >
                    <span>📅</span>
                    <span>
                      {selectedDateTransactions.length > 0
                        ? `本日 (${selectedDate}) 已記 ${selectedDateTransactions.length} 筆 ✍️`
                        : "今日尚未記帳 ✍️"}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      playKawaiiSound("stamp", soundEnabled);
                      setIsQuickRecordOpen(true);
                    }}
                    className="sticker-btn px-6 py-3 rounded-full bg-gradient-to-r from-[#FF4785] to-[#B833FF] text-white text-sm font-black flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4 stroke-[3]" />
                    <span>快速記一筆</span>
                  </button>
                </div>
              </div>
            </section>

            {/* BOTTOM 2-COLUMN BENTO GRID: CONCERT GOAL (LEFT 7/12) + MONTHLY BUDGET (RIGHT 5/12) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* LEFT COLUMN (7/12): PRIMARY CONCERT GOAL OR HAND-DRAWN COMPASS EMPTY STATE */}
              <div className="lg:col-span-7 flex flex-col">
                {!primaryGoal || previewEmptyConcert ? (
                  /* Hand-Drawn Compass & Stage Treasure Map Empty State (Matches Screenshot 2!) */
                  <div className="sketch-card bg-[#FFFDF7] p-8 flex-1 flex flex-col items-center justify-center text-center relative overflow-hidden">
                    <div
                      className="washi-tape-pink absolute -top-3 left-1/2 -translate-x-1/2 w-28 h-5 rounded-sm"
                      style={{ transform: "translateX(-50%) rotate(-2deg)" }}
                    />

                    {primaryGoal && (
                      <button
                        onClick={() => setPreviewEmptyConcert(false)}
                        className="absolute top-4 right-4 text-xs font-black px-3 py-1 rounded-full bg-[#FFE3EC] text-[#FF5C8A] border border-[#4A3728] cursor-pointer"
                      >
                        ← 返回已設定門票
                      </button>
                    )}

                    {/* Cute Hand-Drawn Compass & Star Map SVG */}
                    <div className="w-20 h-20 rounded-full bg-[#FFE3EC] border-[2.5px] border-[#4A3728] shadow-[4px_4px_0px_#4A3728] flex items-center justify-center mb-4 animate-float-slow">
                      <Compass className="w-10 h-10 text-[#FF4785] stroke-[2.2]" />
                    </div>

                    <h2 className="text-xl font-black text-[#4A3728] mb-1.5">
                      尚未設定主要演唱會目標
                    </h2>
                    <p className="text-sm font-bold text-[#8C7365] max-w-md mb-6">
                      設定你想參加的下一場偶像舞台，啟動專屬手繪存錢地圖與門票存根！
                    </p>

                    <button
                      onClick={() => {
                        playKawaiiSound("stamp", soundEnabled);
                        setIsConcertModalOpen(true);
                      }}
                      className="sticker-btn px-7 py-3 rounded-full bg-[#FF3B75] text-white text-sm font-black flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                      <span>建立第一個演唱會目標</span>
                    </button>
                  </div>
                ) : (
                  /* Populated Hand-Drawn Perforated Concert Ticket Goal Card */
                  <div className="sketch-card bg-[#FFF8FA] p-6 md:p-7 flex-1 flex flex-col justify-between relative overflow-hidden">
                    {/* Ticket Side Perforation Cutouts */}
                    <div className="w-7 h-7 rounded-full bg-[#FFFDF7] border-[2.5px] border-[#4A3728] absolute -left-4 top-1/2 -translate-y-1/2" />
                    <div className="w-7 h-7 rounded-full bg-[#FFFDF7] border-[2.5px] border-[#4A3728] absolute -right-4 top-1/2 -translate-y-1/2" />

                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 rounded-full bg-[#FF4785] text-white text-xs font-black border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728]">
                            🎫 主要演唱會目標
                          </span>
                          <span className="px-3 py-1 rounded-full bg-[#FFF3B0] text-[#4A3728] text-xs font-black border-2 border-[#4A3728]">
                            💺 {primaryGoal.seatZone}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setPreviewEmptyConcert(true)}
                            className="text-xs font-bold text-[#8C7365] hover:text-[#4A3728] underline cursor-pointer"
                            title="預覽未設定目標時的空狀態插畫"
                          >
                            預覽空狀態
                          </button>
                          <button
                            onClick={() => setIsConcertModalOpen(true)}
                            className="sticker-btn-soft px-3 py-1 rounded-full bg-white text-xs font-black text-[#4A3728]"
                          >
                            + 新增舞台
                          </button>
                        </div>
                      </div>

                      <div className="flex items-start gap-4 mb-4">
                        <HandDrawnSticker sticker="ticket" size={52} />
                        <div>
                          <h2 className="text-xl font-black text-[#4A3728] leading-snug">
                            {primaryGoal.title}
                          </h2>
                          <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-[#8C7365] mt-1">
                            <span>🎤 {primaryGoal.artist}</span>
                            <span>📍 {primaryGoal.venue}</span>
                            <span className="font-mono-num text-[#4A3728] bg-white px-2 py-0.5 rounded-md border border-[#4A3728]">
                              📅 {primaryGoal.concertDate}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Ticket Savings Progress Box */}
                      <div className="bg-white p-4 rounded-2xl border-2 border-[#4A3728] shadow-[3px_3px_0px_#F0DCE4] mb-4">
                        <div className="flex items-baseline justify-between mb-2">
                          <span className="text-xs font-black text-[#8C7365]">
                            💎 演唱會存錢筒進度
                          </span>
                          <div className="font-mono-num text-lg font-black">
                            <span className="text-[#FF4785]">
                              NT$ {primaryGoal.allocatedAmount.toLocaleString()}
                            </span>
                            <span className="text-xs text-[#8C7365] mx-1">
                              /
                            </span>
                            <span className="text-sm text-[#4A3728]">
                              NT$ {primaryGoal.targetAmount.toLocaleString()}
                            </span>
                          </div>
                        </div>

                        <div className="w-full h-4 rounded-full bg-[#F5EBE1] border-2 border-[#4A3728] overflow-hidden p-0.5">
                          <div
                            className="h-full rounded-full crayon-stripe-pink transition-all duration-500"
                            style={{
                              width: `${Math.min(
                                100,
                                Math.round(
                                  (primaryGoal.allocatedAmount /
                                    Math.max(1, primaryGoal.targetAmount)) *
                                    100
                                )
                              )}%`,
                            }}
                          />
                        </div>

                        <div className="flex items-center justify-between text-[11px] font-bold text-[#8C7365] mt-2">
                          <span>
                            已達成{" "}
                            <strong className="font-mono-num text-[#FF4785]">
                              {Math.min(
                                100,
                                Math.round(
                                  (primaryGoal.allocatedAmount /
                                    Math.max(1, primaryGoal.targetAmount)) *
                                    100
                                )
                              )}
                              %
                            </strong>
                          </span>
                          <span>
                            還差 NT${" "}
                            <strong className="font-mono-num text-[#4A3728]">
                              {Math.max(
                                0,
                                primaryGoal.targetAmount -
                                  primaryGoal.allocatedAmount
                              ).toLocaleString()}
                            </strong>{" "}
                            即可全額解鎖門票與周邊！
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Perforated Tear Line & Quick Deposit Buttons */}
                    <div className="border-t-2 border-dashed border-[#4A3728]/35 pt-4 flex flex-wrap items-center justify-between gap-3">
                      <span className="text-xs font-bold text-[#6E5646] line-clamp-1">
                        📌 {primaryGoal.notes}
                      </span>

                      <div className="flex items-center gap-2 ml-auto">
                        <button
                          onClick={async () => {
                            playKawaiiSound("coin", soundEnabled);
                            await postAction({
                              action: "allocate_concert_fund",
                              goalId: primaryGoal.id,
                              addAmount: 500,
                            });
                            showToast(
                              "💎 已撥款 NT$ 500 進入演唱會基金！(+25 XP / +35 P)"
                            );
                          }}
                          className="sticker-btn px-3.5 py-1.5 rounded-full bg-[#FFF0B8] text-xs font-black text-[#4A3728]"
                        >
                          + 存入 $500
                        </button>
                        <button
                          onClick={() => {
                            playKawaiiSound("click", soundEnabled);
                            setActiveTab("concert");
                          }}
                          className="sticker-btn px-4 py-1.5 rounded-full bg-[#4A3728] text-white text-xs font-black"
                        >
                          存錢地圖 →
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* RIGHT COLUMN (5/12): MONTHLY CONSUMPTION BUDGET ENVELOPE (Matches Screenshot 2!) */}
              <div className="lg:col-span-5 sketch-card bg-white p-6 md:p-7 flex flex-col justify-between relative">
                <div
                  className="washi-tape-mint absolute -top-3 left-1/2 -translate-x-1/2 w-28 h-5 rounded-sm"
                  style={{ transform: "translateX(-50%) rotate(2deg)" }}
                />

                <div className="space-y-4">
                  {/* Top Header */}
                  <div className="flex items-center justify-between border-b-2 border-dashed border-[#E6D7C3] pb-3">
                    <span className="text-base font-black text-[#4A3728] flex items-center gap-1.5">
                      👛 本月消費預算（{currentMonth}月）
                    </span>
                    <button
                      onClick={() => {
                        playKawaiiSound("click", soundEnabled);
                        setIsBudgetModalOpen(true);
                      }}
                      className="text-xs font-black text-[#FF3B75] hover:underline px-2.5 py-1 rounded-full bg-[#FFE3EC] border border-[#4A3728] cursor-pointer"
                    >
                      調整預算
                    </button>
                  </div>

                  {/* Remaining Budget Display */}
                  <div>
                    <div className="text-xs font-bold text-[#8C7365] mb-1">
                      本月剩餘可用額度
                    </div>
                    <div className="font-mono-num text-3xl sm:text-4xl font-black text-[#4A3728] tracking-tight">
                      NT$ {metrics.monthlyRemainingBudget.toLocaleString()}
                    </div>
                    <div className="text-xs font-bold text-[#8C7365] mt-1.5">
                      預算上限：NT$ {profile.monthlyBudget.toLocaleString()}・已使用{" "}
                      <span className="font-mono-num text-[#FF4785] font-black">
                        {metrics.budgetUsedPct}%
                      </span>
                    </div>
                  </div>

                  {/* Hand-drawn Crayon Progress Bar */}
                  <div className="w-full h-3.5 rounded-full bg-[#F5EBE1] border-2 border-[#4A3728] overflow-hidden p-0.5">
                    <div
                      className="h-full rounded-full crayon-stripe-mint transition-all duration-500"
                      style={{
                        width: `${Math.max(4, metrics.budgetUsedPct)}%`,
                      }}
                    />
                  </div>

                  {/* 2 Sub-Envelopes: Daily Life vs Idol Expense */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div className="p-3.5 rounded-2xl bg-[#FFFDF5] border-2 border-[#4A3728] shadow-[2px_2px_0px_#E6D7C3]">
                      <div className="text-xs font-bold text-[#8C7365] flex items-center gap-1 mb-1">
                        <span>🍱</span>
                        <span>日常生活</span>
                      </div>
                      <div className="font-mono-num text-base font-black text-[#4A3728]">
                        NT$ {metrics.monthDailyExpense.toLocaleString()}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-[#FFF2F7] border-2 border-[#4A3728] shadow-[2px_2px_0px_#F5CEDC]">
                      <div className="text-xs font-bold text-[#FF3B75] flex items-center gap-1 mb-1">
                        <span>🎤</span>
                        <span>追星消費</span>
                      </div>
                      <div className="font-mono-num text-base font-black text-[#FF3B75]">
                        NT$ {metrics.monthIdolExpense.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Allocated Concert Fund Row */}
                <div className="border-t-2 border-dashed border-[#E6D7C3] pt-4 mt-5 flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-black text-[#6E5646] flex items-center gap-1.5">
                    <span>💎</span>
                    <span>已分配演唱會基金</span>
                  </span>
                  <span className="font-mono-num text-base font-black text-[#9B33FF]">
                    NT$ {metrics.allocatedConcertFund.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* QUICK RECENT JOURNAL STICKERS BAR ON HOME PAGE */}
            <section className="sketch-card bg-white p-5 md:p-6">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-lg">📒</span>
                  <h3 className="text-base font-black text-[#4A3728]">
                    近期手帳貼紙明細
                  </h3>
                  <span className="text-xs text-[#8C7365] font-bold">
                    （點擊可切換至月曆記帳檢視完整日誌）
                  </span>
                </div>
                <button
                  onClick={() => {
                    playKawaiiSound("click", soundEnabled);
                    setActiveTab("ledger");
                  }}
                  className="sticker-btn-soft px-3.5 py-1 rounded-full bg-[#FFF6D6] text-xs font-black text-[#4A3728]"
                >
                  前往月曆記帳 📅 →
                </button>
              </div>

              {transactions.length === 0 ? (
                <div className="sketch-dashed-box p-6 text-center text-xs font-bold text-[#8C7365]">
                  目前尚無記帳紀錄，點擊右上角「快速記一筆」開始你的星途手帳吧！
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {transactions.slice(0, 4).map((t) => (
                    <div
                      key={t.id}
                      onClick={() => {
                        setSelectedDate(t.date);
                        setActiveTab("ledger");
                      }}
                      className="p-3 rounded-2xl border-2 border-[#4A3728] bg-[#FFFDF7] hover:bg-[#FFF3F8] flex items-center justify-between gap-2.5 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <HandDrawnSticker sticker={t.sticker} size={36} />
                        <div className="min-w-0">
                          <div className="text-xs font-black text-[#4A3728] truncate">
                            {t.title}
                          </div>
                          <div className="text-[11px] font-mono-num text-[#8C7365]">
                            {t.date} · {t.category}
                          </div>
                        </div>
                      </div>
                      <span
                        className={`font-mono-num text-xs font-black shrink-0 ${
                          t.type === "income"
                            ? "text-[#2BB58A]"
                            : "text-[#FF3B75]"
                        }`}
                      >
                        {t.type === "income" ? "+" : "-"}NT${" "}
                        {t.amount.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        ) : activeTab === "ledger" ? (
          /* =====================================================================
             TAB 3: 📅 追星記帳 (經紀日誌｜月曆記帳 — SCREENSHOT 1 REDESIGN)
             ===================================================================== */
          <div className="space-y-5">
            {/* Top Section Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-black text-[#4A3728] flex items-center gap-2">
                  <span className="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-[#FFE3EC] border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728] text-lg">
                    📅
                  </span>
                  <span>經紀日誌｜月曆記帳</span>
                </h1>
                <p className="text-xs sm:text-sm font-bold text-[#8C7365] mt-1">
                  完整互動手繪月曆、點擊日期查看當日收據明細、即時蓋章新增收支紀錄
                </p>
              </div>

              {/* Right View Switcher Pill + Record Button */}
              <div className="flex items-center gap-3 self-start sm:self-center">
                <div className="inline-flex p-1 rounded-full bg-[#F5EBE1] border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728]">
                  <button
                    onClick={() => {
                      playKawaiiSound("click", soundEnabled);
                      setLedgerViewMode("calendar");
                    }}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all ${
                      ledgerViewMode === "calendar"
                        ? "bg-white text-[#FF3B75] border border-[#4A3728] shadow-xs"
                        : "text-[#6E5646]"
                    }`}
                  >
                    <CalendarIcon className="w-3.5 h-3.5" />
                    <span>月曆檢視</span>
                  </button>
                  <button
                    onClick={() => {
                      playKawaiiSound("click", soundEnabled);
                      setLedgerViewMode("list");
                    }}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all ${
                      ledgerViewMode === "list"
                        ? "bg-white text-[#FF3B75] border border-[#4A3728] shadow-xs"
                        : "text-[#6E5646]"
                    }`}
                  >
                    <ListFilter className="w-3.5 h-3.5" />
                    <span>清單檢視</span>
                  </button>
                </div>

                <button
                  onClick={() => {
                    playKawaiiSound("stamp", soundEnabled);
                    setIsQuickRecordOpen(true);
                  }}
                  className="sticker-btn px-5 py-2.5 rounded-full bg-[#FF2E7E] text-white text-xs sm:text-sm font-black flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>記一筆</span>
                </button>
              </div>
            </div>

            {/* Month Selector Bar */}
            <div className="sketch-card bg-white px-5 py-3.5 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={handlePrevMonth}
                  className="sticker-btn-soft w-9 h-9 rounded-xl bg-[#FFF8EB] flex items-center justify-center text-[#4A3728]"
                  title="上個月"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="font-mono-num text-lg sm:text-xl font-black text-[#4A3728] px-2">
                  {currentYear} 年 {currentMonth} 月
                </div>
                <button
                  onClick={handleNextMonth}
                  className="sticker-btn-soft w-9 h-9 rounded-xl bg-[#FFF8EB] flex items-center justify-center text-[#4A3728]"
                  title="下個月"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>

                {/* Monthly quick badges */}
                <div className="hidden md:flex items-center gap-2 ml-3 pl-3 border-l-2 border-dashed border-[#E6D7C3]">
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#FFF0F5] text-[#FF3B75] border border-[#4A3728]">
                    本月支出：
                    <strong className="font-mono-num">
                      NT$ {metrics.monthTotalExpense.toLocaleString()}
                    </strong>
                  </span>
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#E8FBF4] text-[#1E9E73] border border-[#4A3728]">
                    本月收入：
                    <strong className="font-mono-num">
                      NT$ {metrics.monthTotalIncome.toLocaleString()}
                    </strong>
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    playKawaiiSound("click", soundEnabled);
                    setCurrentYear(2026);
                    setCurrentMonth(11);
                    setSelectedDate("2026-11-04");
                  }}
                  className="sticker-btn-soft px-3.5 py-1.5 rounded-xl bg-[#FFF3CD] text-xs font-black text-[#4A3728]"
                >
                  📌 2026-11-04 (範例日)
                </button>
                <button
                  onClick={() => {
                    playKawaiiSound("click", soundEnabled);
                    const now = new Date();
                    const y = now.getFullYear();
                    const m = now.getMonth() + 1;
                    const d = now.getDate();
                    setCurrentYear(y);
                    setCurrentMonth(m);
                    setSelectedDate(
                      `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(
                        2,
                        "0"
                      )}`
                    );
                  }}
                  className="sticker-btn-soft px-3.5 py-1.5 rounded-xl bg-white text-xs font-black text-[#4A3728]"
                >
                  回到今天
                </button>
              </div>
            </div>

            {ledgerViewMode === "calendar" ? (
              /* ==================== SPLIT VIEW: SPIRAL CALENDAR (8/12) + RECEIPT PAD (4/12) ==================== */
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* LEFT 8/12: HAND-DRAWN SPIRAL-BOUND MONTHLY CALENDAR */}
                <div className="lg:col-span-8 sketch-card bg-white p-4 sm:p-6 relative pt-8">
                  {/* Decorative Notebook Spiral Rings Along Top Edge */}
                  <div className="absolute -top-3 inset-x-8 flex justify-around pointer-events-none">
                    {Array.from({ length: 10 }).map((_, i) => (
                      <div
                        key={i}
                        className="w-3.5 h-6 rounded-full bg-[#FFF8EB] border-2 border-[#4A3728] shadow-[1px_1px_0px_#4A3728]"
                      />
                    ))}
                  </div>

                  {/* Weekday Header Row */}
                  <div className="grid grid-cols-7 gap-2 mb-3 text-center">
                    {["週一", "週二", "週三", "週四", "週五", "週六", "週日"].map(
                      (dayName, idx) => {
                        const isWknd = idx >= 5;
                        return (
                          <div
                            key={dayName}
                            className={`py-1.5 text-xs sm:text-sm font-black rounded-xl ${
                              isWknd
                                ? "text-[#FF2E7E] bg-[#FFF0F6]"
                                : "text-[#6E5646] bg-[#FFF9F0]"
                            }`}
                          >
                            {dayName}
                          </div>
                        );
                      }
                    )}
                  </div>

                  {/* Calendar Days Grid */}
                  <div className="grid grid-cols-7 gap-2 sm:gap-2.5">
                    {calendarCells.map((cell) => {
                      const isSelected = cell.dateStr === selectedDate;
                      const dayTxs = transactions.filter(
                        (t) => t.date === cell.dateStr
                      );
                      const dayExp = dayTxs
                        .filter((t) => t.type === "expense")
                        .reduce((s, t) => s + t.amount, 0);
                      const dayInc = dayTxs
                        .filter((t) => t.type === "income")
                        .reduce((s, t) => s + t.amount, 0);

                      return (
                        <button
                          key={cell.dateStr}
                          type="button"
                          onClick={() => {
                            playKawaiiSound("click", soundEnabled);
                            setSelectedDate(cell.dateStr);
                          }}
                          className={`min-h-[82px] sm:min-h-[98px] p-2 rounded-2xl text-left flex flex-col justify-between transition-all cursor-pointer relative ${
                            !cell.isCurrentMonth
                              ? "bg-[#FAF6F0]/60 border border-dashed border-[#E5D5C5] text-[#C2B2A3]"
                              : isSelected
                              ? "bg-[#FFE3EE] border-[2.5px] border-[#FF2E7E] shadow-[3px_3px_0px_#FF2E7E] -translate-y-0.5"
                              : "bg-[#FFFDF9] border-2 border-[#E6D7C3] hover:border-[#4A3728] hover:bg-[#FFF9F2]"
                          }`}
                        >
                          {/* Date Number & Selected Pin */}
                          <div className="flex items-center justify-between w-full">
                            <span
                              className={`font-mono-num text-xs sm:text-sm font-black ${
                                isSelected
                                  ? "text-[#FF2E7E]"
                                  : !cell.isCurrentMonth
                                  ? "text-[#C2B2A3]"
                                  : cell.isWeekend
                                  ? "text-[#FF5C8A]"
                                  : "text-[#4A3728]"
                              }`}
                            >
                              {cell.day}
                            </span>

                            {isSelected && (
                              <span className="text-[11px] leading-none">
                                ⭐
                              </span>
                            )}
                          </div>

                          {/* Hand-Drawn Sticker Stamps Preview in Calendar Cell */}
                          {dayTxs.length > 0 && (
                            <div className="my-1 flex flex-wrap gap-1">
                              {dayTxs.slice(0, 3).map((t) => (
                                <HandDrawnSticker
                                  key={t.id}
                                  sticker={t.sticker}
                                  size={22}
                                />
                              ))}
                              {dayTxs.length > 3 && (
                                <span className="text-[10px] font-mono-num font-black text-[#8C7365] self-center">
                                  +{dayTxs.length - 3}
                                </span>
                              )}
                            </div>
                          )}

                          {/* Compact Daily Net Pill */}
                          <div className="w-full space-y-0.5">
                            {dayExp > 0 && (
                              <div className="font-mono-num text-[10px] font-black text-[#FF2E7E] bg-white/90 px-1.5 py-0.5 rounded-md border border-[#FF94B8] truncate">
                                -${dayExp.toLocaleString()}
                              </div>
                            )}
                            {dayInc > 0 && (
                              <div className="font-mono-num text-[10px] font-black text-[#1E9E73] bg-[#E8FBF4] px-1.5 py-0.5 rounded-md border border-[#8CE0C2] truncate">
                                +${dayInc.toLocaleString()}
                              </div>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* RIGHT 4/12: TEAR-OFF DAILY RECEIPT PAD (當日收支紀錄) */}
                <div className="lg:col-span-4 sketch-card bg-[#FFFDF9] p-5 sm:p-6 relative flex flex-col justify-between min-h-[480px]">
                  {/* Top Washi Tape */}
                  <div
                    className="washi-tape-pink absolute -top-3 left-1/2 -translate-x-1/2 w-28 h-5 rounded-sm"
                    style={{ transform: "translateX(-50%) rotate(2deg)" }}
                  />

                  <div>
                    {/* Receipt Header */}
                    <div className="flex items-start justify-between gap-2 pb-4 border-b-2 border-dashed border-[#E6D7C3]">
                      <div>
                        <div className="text-xs font-bold text-[#8C7365] flex items-center gap-1.5 mb-1">
                          <span>🗂️</span>
                          <span>當日收支紀錄</span>
                        </div>
                        <div className="font-mono-num text-xl font-black text-[#4A3728]">
                          {selectedDate}
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          playKawaiiSound("stamp", soundEnabled);
                          setIsQuickRecordOpen(true);
                        }}
                        className="sticker-btn-soft px-3.5 py-1.5 rounded-full bg-[#FFE3EC] text-[#FF2E7E] text-xs font-black"
                      >
                        + 新增本日帳目
                      </button>
                    </div>

                    {/* Today Expense vs Today Income Summary Boxes */}
                    <div className="grid grid-cols-2 gap-3 my-4">
                      <div className="p-3.5 rounded-2xl bg-[#FFF5F8] border-2 border-[#4A3728] shadow-[2px_2px_0px_#F5CEDC]">
                        <div className="text-xs font-bold text-[#8C7365] mb-1">
                          今日支出總計
                        </div>
                        <div className="font-mono-num text-lg font-black text-[#FF2E7E]">
                          NT$ {selectedDateExpense.toLocaleString()}
                        </div>
                      </div>

                      <div className="p-3.5 rounded-2xl bg-[#F2FBF7] border-2 border-[#4A3728] shadow-[2px_2px_0px_#C6EEDF]">
                        <div className="text-xs font-bold text-[#8C7365] mb-1">
                          今日收入總計
                        </div>
                        <div className="font-mono-num text-lg font-black text-[#1E9E73]">
                          NT$ {selectedDateIncome.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    {/* Transactions List or Cute Empty State */}
                    {selectedDateTransactions.length === 0 ? (
                      <div className="py-12 px-4 text-center space-y-3 my-2 rounded-2xl border-2 border-dashed border-[#E6D7C3] bg-white/70">
                        <div className="w-14 h-14 mx-auto rounded-full bg-[#FFF5D6] border-2 border-[#4A3728] flex items-center justify-center text-2xl shadow-[2px_2px_0px_#4A3728]">
                          🌟
                        </div>
                        <div className="text-sm font-bold text-[#8C7365]">
                          本日尚無收支明細 🌟
                        </div>
                        <button
                          onClick={() => {
                            playKawaiiSound("stamp", soundEnabled);
                            setIsQuickRecordOpen(true);
                          }}
                          className="text-xs sm:text-sm font-black text-[#FF2E7E] hover:underline cursor-pointer inline-block"
                        >
                          點此為 {selectedDate} 記錄第一筆
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-3 mt-2 max-h-[380px] overflow-y-auto pr-1">
                        {selectedDateTransactions.map((tx) => (
                          <div
                            key={tx.id}
                            className="p-3.5 rounded-2xl bg-white border-2 border-[#4A3728] shadow-[2.5px_2.5px_0px_#E6D7C3] flex items-start justify-between gap-2.5 group"
                          >
                            <div className="flex items-start gap-2.5 min-w-0">
                              <HandDrawnSticker sticker={tx.sticker} size={38} />
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span
                                    className={`text-[10px] font-black px-2 py-0.5 rounded-full border border-[#4A3728] ${
                                      tx.groupType === "idol"
                                        ? "bg-[#FFE3EC] text-[#FF2E7E]"
                                        : tx.groupType === "income"
                                        ? "bg-[#E4FBF0] text-[#1E9E73]"
                                        : "bg-[#FFF3C4] text-[#4A3728]"
                                    }`}
                                  >
                                    {tx.category}
                                  </span>
                                </div>
                                <div className="text-sm font-black text-[#4A3728] mt-1 break-words">
                                  {tx.title}
                                </div>
                                {tx.note && (
                                  <div className="text-xs text-[#8C7365] mt-0.5">
                                    ✎ {tx.note}
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="flex flex-col items-end shrink-0 gap-1">
                              <span
                                className={`font-mono-num text-sm font-black ${
                                  tx.type === "income"
                                    ? "text-[#1E9E73]"
                                    : "text-[#FF2E7E]"
                                }`}
                              >
                                {tx.type === "income" ? "+" : "-"}NT${" "}
                                {tx.amount.toLocaleString()}
                              </span>
                              <button
                                onClick={async () => {
                                  playKawaiiSound("click", soundEnabled);
                                  await postAction({
                                    action: "delete_transaction",
                                    id: tx.id,
                                  });
                                  showToast("🗑️ 已從手帳撕下該筆紀錄");
                                }}
                                className="text-[#C2B2A3] hover:text-[#FF5C77] p-1 cursor-pointer"
                                title="刪除此筆紀錄"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Bottom Receipt Barcode / Memo Footer */}
                  <div className="border-t-2 border-dashed border-[#E6D7C3] pt-3 mt-4 flex items-center justify-between text-[11px] font-bold text-[#8C7365]">
                    <span>STAR WALK 經紀日誌收據聯</span>
                    <span className="font-mono-num">
                      共 {selectedDateTransactions.length} 筆印章
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              /* ==================== LIST VIEW (📋 清單檢視) ==================== */
              <div className="sketch-card bg-white p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-dashed border-[#E6D7C3] pb-4">
                  <div className="flex flex-wrap gap-2">
                    {[
                      { id: "all", label: "📒 全部帳目" },
                      { id: "idol", label: "🎤 追星消費" },
                      { id: "daily", label: "🍱 日常生活" },
                      { id: "income", label: "💰 收入回血" },
                    ].map((f) => (
                      <button
                        key={f.id}
                        onClick={() =>
                          setListFilterGroup(
                            f.id as "all" | "idol" | "daily" | "income"
                          )
                        }
                        className={`sticker-btn-soft px-4 py-1.5 rounded-full text-xs font-black ${
                          listFilterGroup === f.id
                            ? "bg-[#4A3728] text-white"
                            : "bg-[#FFFDF7] text-[#4A3728]"
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                  <div className="text-xs font-bold text-[#8C7365]">
                    總計 {transactions.length} 筆手帳紀錄
                  </div>
                </div>

                <div className="space-y-2.5">
                  {transactions
                    .filter((t) =>
                      listFilterGroup === "all"
                        ? true
                        : t.groupType === listFilterGroup
                    )
                    .map((tx) => (
                      <div
                        key={tx.id}
                        className="p-4 rounded-2xl border-2 border-[#4A3728] bg-[#FFFDF7] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3.5">
                          <HandDrawnSticker sticker={tx.sticker} size={42} />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono-num text-xs font-bold text-[#8C7365]">
                                {tx.date}
                              </span>
                              <span
                                className={`text-[10px] font-black px-2 py-0.5 rounded-full border border-[#4A3728] ${
                                  tx.groupType === "idol"
                                    ? "bg-[#FFE3EC] text-[#FF2E7E]"
                                    : tx.groupType === "income"
                                    ? "bg-[#E4FBF0] text-[#1E9E73]"
                                    : "bg-[#FFF3C4] text-[#4A3728]"
                                }`}
                              >
                                {tx.category}
                              </span>
                            </div>
                            <div className="text-base font-black text-[#4A3728] mt-0.5">
                              {tx.title}
                            </div>
                            {tx.note && (
                              <div className="text-xs text-[#8C7365]">
                                ✎ {tx.note}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-dashed border-[#E5D5C5]">
                          <span
                            className={`font-mono-num text-base font-black ${
                              tx.type === "income"
                                ? "text-[#1E9E73]"
                                : "text-[#FF2E7E]"
                            }`}
                          >
                            {tx.type === "income" ? "+" : "-"}NT${" "}
                            {tx.amount.toLocaleString()}
                          </span>
                          <button
                            onClick={async () => {
                              await postAction({
                                action: "delete_transaction",
                                id: tx.id,
                              });
                              showToast("🗑️ 已刪除該筆帳目");
                            }}
                            className="text-[#8C7365] hover:text-[#FF5C77] p-1.5 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        ) : activeTab === "concert" ? (
          <ConcertJourneyTab
            goals={concertGoals}
            availableUnallocated={metrics.availableUnallocated}
            onOpenNewGoal={() => {
              playKawaiiSound("stamp", soundEnabled);
              setIsConcertModalOpen(true);
            }}
            onAllocateFund={async (goalId, amount) => {
              playKawaiiSound("coin", soundEnabled);
              await postAction({
                action: "allocate_concert_fund",
                goalId,
                addAmount: amount,
              });
              showToast(
                `💎 成功撥款 NT$ ${amount.toLocaleString()} 至演唱會門票基金！`
              );
            }}
            onSetPrimary={async (goalId) => {
              playKawaiiSound("click", soundEnabled);
              await postAction({ action: "set_primary_concert", goalId });
              showToast("🌟 已更新首頁主要演唱會目標！");
            }}
            onDeleteGoal={async (goalId) => {
              playKawaiiSound("click", soundEnabled);
              await postAction({ action: "delete_concert_goal", goalId });
              showToast("已移除該場演唱會目標");
            }}
          />
        ) : activeTab === "analytics" ? (
          <AnalyticsTab
            transactions={transactions}
            monthlyBudget={profile.monthlyBudget}
            allocatedConcertFund={metrics.allocatedConcertFund}
          />
        ) : activeTab === "collection" ? (
          <CollectionBookTab
            collections={collections}
            onAddCollection={async (item) => {
              playKawaiiSound("stamp", soundEnabled);
              await postAction({ action: "add_collection", ...item });
              showToast("💖 已將新寶貝收進九宮格收藏冊！(+20 XP / +30 P)");
            }}
            onDeleteCollection={async (id) => {
              await postAction({ action: "delete_collection", id });
              showToast("已從收藏冊移除項目");
            }}
          />
        ) : activeTab === "character" ? (
          <CharacterQuestsTab
            profile={profile}
            onSelectOutfit={async (outfitId) => {
              playKawaiiSound("stamp", soundEnabled);
              await postAction({
                action: "update_profile",
                currentOutfit: outfitId,
              });
              showToast("👗 換裝完成！去星途首頁看看新造型吧！");
            }}
            onUnlockOutfit={async (outfitId, cost) => {
              playKawaiiSound("levelup", soundEnabled);
              await postAction({
                action: "update_profile",
                unlockOutfitId: outfitId,
                unlockCost: cost,
              });
              showToast("🎉 成功解鎖並換上新應援穿搭！");
            }}
            onClaimQuest={async (xp, coins) => {
              playKawaiiSound("levelup", soundEnabled);
              await postAction({
                action: "claim_quest",
                xpReward: xp,
                coinReward: coins,
              });
              showToast(`🎁 任務完成！獲得 +${xp} XP 與 +${coins} 星光幣！`);
            }}
          />
        ) : (
          <MemoryHallTab
            collections={collections}
            goals={concertGoals}
            onSwitchToCollection={() => setActiveTab("collection")}
          />
        )}

        {/* ==================== BOTTOM HAND-DRAWN MODE SWITCHER FOOTER ==================== */}
        <footer className="pt-6 border-t-2 border-dashed border-[#E0C8B4] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-bold text-[#8C7365]">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-4 h-4 text-[#FF5C8A]" />
            <span>
              STAR WALK 星途手繪記帳本 — 為每一位認真生活、努力奔向偶像舞台的經紀人而設計
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                playKawaiiSound("stamp", soundEnabled);
                await postAction({ action: "reset_demo" });
                setPreviewEmptyConcert(false);
                showToast("✨ 已載入豐富手繪範例資料（含 2026-11 月曆與演唱會門票）");
              }}
              className="sticker-btn-soft px-3 py-1.5 rounded-full bg-[#FFE3EC] text-[#4A3728] flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#FF2E7E]" />
              <span>載入豐富範例資料</span>
            </button>

            <button
              onClick={async () => {
                playKawaiiSound("click", soundEnabled);
                await postAction({ action: "reset_zero" });
                showToast("🔄 已切換為截圖初始歸零狀態 (NT$ 0)");
              }}
              className="sticker-btn-soft px-3 py-1.5 rounded-full bg-white text-[#4A3728] flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>切換為 NT$ 0 初始狀態</span>
            </button>
          </div>
        </footer>
      </main>

      {/* ==================== INTERACTIVE MODALS ==================== */}
      <QuickRecordModal
        isOpen={isQuickRecordOpen}
        onClose={() => setIsQuickRecordOpen(false)}
        defaultDate={selectedDate}
        onSubmit={async (data) => {
          playKawaiiSound("stamp", soundEnabled);
          await postAction({ action: "add_transaction", ...data });
          setSelectedDate(data.date);
          showToast(
            `✍️ 已蓋章記錄「${data.title}」NT$ ${data.amount.toLocaleString()}！(+15 XP / +25 P)`
          );
        }}
      />

      <ConcertGoalModal
        isOpen={isConcertModalOpen}
        onClose={() => setIsConcertModalOpen(false)}
        onSubmit={async (data) => {
          playKawaiiSound("levelup", soundEnabled);
          await postAction({ action: "add_concert_goal", ...data });
          setPreviewEmptyConcert(false);
          showToast("🎫 成功建立新的演唱會夢想門票！(+30 XP / +50 P)");
        }}
      />

      <BudgetSettingsModal
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
        currentBudget={profile.monthlyBudget}
        currentBaseSavings={profile.baseSavings}
        onUpdateBudget={async (monthlyBudget, baseSavings) => {
          playKawaiiSound("coin", soundEnabled);
          await postAction({
            action: "update_budget",
            monthlyBudget,
            baseSavings,
          });
          showToast("👛 已更新本月消費預算與基礎流動資金！");
        }}
        onResetDemo={async () => {
          playKawaiiSound("stamp", soundEnabled);
          await postAction({ action: "reset_demo" });
          setPreviewEmptyConcert(false);
          showToast("✨ 已還原豐富手繪範例資料！");
        }}
        onResetZero={async () => {
          playKawaiiSound("click", soundEnabled);
          await postAction({ action: "reset_zero" });
          showToast("🔄 已切換為 NT$ 0 初始歸零狀態！");
        }}
      />
    </div>
  );
}
