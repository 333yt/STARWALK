"use client";

import React from "react";

export type OutfitId =
  | "hoodie_pink"
  | "starlight_cape"
  | "y2k_headphone"
  | "bear_pajama"
  | "royal_uniform";

export interface OutfitMeta {
  id: OutfitId;
  name: string;
  tag: string;
  cost: number;
  desc: string;
  bgColor: string;
  accentColor: string;
}

export const OUTFIT_CATALOG: OutfitMeta[] = [
  {
    id: "hoodie_pink",
    name: "粉嫩帽T練舞服",
    tag: "初始穿搭",
    cost: 0,
    desc: "柔軟草莓粉兔耳連帽T，陪你熬夜刷音源與練應援口號！",
    bgColor: "#FFE4EE",
    accentColor: "#FF6B9D",
  },
  {
    id: "starlight_cape",
    name: "星光應援毛絨斗篷",
    tag: "演唱會必備",
    cost: 150,
    desc: "外場發應援物最吸睛的紫丁香星星斗篷與貝雷帽 ✨",
    bgColor: "#F2E8FF",
    accentColor: "#9B6BFF",
  },
  {
    id: "y2k_headphone",
    name: "Y2K甜酷耳機穿搭",
    tag: "回歸打歌風",
    cost: 200,
    desc: "戴上薄荷蘇打復古耳機，隨時隨地沉浸本命神曲 🎧",
    bgColor: "#E4FBF3",
    accentColor: "#2BB58A",
  },
  {
    id: "bear_pajama",
    name: "小熊牛奶睡衣派對",
    tag: "居家整理小卡",
    cost: 180,
    desc: "毛茸茸奶油小熊連帽睡衣，最適合在書桌前貼手帳！",
    bgColor: "#FFF5D6",
    accentColor: "#E59A28",
  },
  {
    id: "royal_uniform",
    name: "皇家星光學院制服",
    tag: "限定SSR造型",
    cost: 300,
    desc: "繫上草莓紅蝴蝶結的學院風西裝外套，專業經紀人滿分！",
    bgColor: "#FFEBF2",
    accentColor: "#E84A7F",
  },
];

export const STICKER_OPTIONS = [
  { id: "lightstick", label: "應援手燈", emoji: "🎤", color: "#FFE3EC" },
  { id: "photocard", label: "本命小卡", emoji: "🃏", color: "#F2E6FF" },
  { id: "album", label: "正規專輯", emoji: "💿", color: "#E6F4FF" },
  { id: "ticket", label: "演唱會票", emoji: "🎫", color: "#FFF2CC" },
  { id: "boba", label: "手搖珍奶", emoji: "🧋", color: "#FDEBD0" },
  { id: "bento", label: "美味餐點", emoji: "🍱", color: "#FFE8E0" },
  { id: "cake", label: "草莓甜點", emoji: "🍰", color: "#FFE3EC" },
  { id: "train", label: "交通通勤", emoji: "🚃", color: "#E3F8F2" },
  { id: "heart", label: "應援集資", emoji: "💖", color: "#FFE0F0" },
  { id: "sparkles", label: "手帳日常", emoji: "✨", color: "#FFF8D6" },
  { id: "coin", label: "回血收入", emoji: "💰", color: "#E4FBF0" },
];

export function playKawaiiSound(
  type: "click" | "stamp" | "coin" | "levelup",
  enabled = true
) {
  if (!enabled || typeof window === "undefined") return;
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (type === "click") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(520, now);
      osc.frequency.exponentialRampToValueAtTime(780, now + 0.07);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === "stamp") {
      osc.type = "triangle";
      osc.frequency.setValueAtTime(340, now);
      osc.frequency.exponentialRampToValueAtTime(680, now + 0.14);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === "coin") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(660, now);
      osc.frequency.setValueAtTime(880, now + 0.08);
      osc.frequency.setValueAtTime(1100, now + 0.16);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.start(now);
      osc.stop(now + 0.28);
    } else if (type === "levelup") {
      osc.type = "triangle";
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.09);
      osc.frequency.setValueAtTime(783.99, now + 0.18);
      osc.frequency.setValueAtTime(1046.5, now + 0.27);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
      osc.start(now);
      osc.stop(now + 0.42);
    }
  } catch {
    // Ignore audio context policies if blocked
  }
}

export function ChibiManagerAvatar({
  outfit = "hoodie_pink",
  size = 116,
  level = 1,
  showBadge = true,
}: {
  outfit?: string;
  size?: number;
  level?: number;
  showBadge?: boolean;
}) {
  const meta =
    OUTFIT_CATALOG.find((o) => o.id === outfit) || OUTFIT_CATALOG[0];

  return (
    <div
      className="relative inline-flex items-center justify-center select-none"
      style={{ width: size, height: size }}
    >
      {/* Decorative Washi Tape on Top of Polaroid */}
      <div
        className="washi-tape-pink absolute -top-2.5 left-1/2 -translate-x-1/2 w-14 h-4 z-20 rounded-sm"
        style={{ transform: "translateX(-50%) rotate(-4deg)" }}
      />

      {/* Hand-drawn Polaroid Frame */}
      <div
        className="w-full h-full rounded-[24px] border-[2.5px] border-[#4A3728] overflow-hidden relative flex items-center justify-center shadow-[3px_3px_0px_#4A3728]"
        style={{ backgroundColor: meta.bgColor }}
      >
        {/* Subtle Hand-Drawn Sparkle Background Dots */}
        <svg
          viewBox="0 0 120 120"
          className="w-full h-full animate-float-slow"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Floating background stars */}
          <path
            d="M18 24L20 29L25 31L20 33L18 38L16 33L11 31L16 29L18 24Z"
            fill="#FFD84D"
            stroke="#4A3728"
            strokeWidth="1.5"
          />
          <circle
            cx="100"
            cy="24"
            r="4"
            fill="#FF8BB3"
            stroke="#4A3728"
            strokeWidth="1.5"
          />
          <circle cx="20" cy="88" r="3" fill="#9EE6CF" />

          {/* Outfit-specific Headwear / Ears Back Layer */}
          {outfit === "hoodie_pink" && (
            <g>
              {/* Cute Bunny Hoodie Ears */}
              <ellipse
                cx="38"
                cy="25"
                rx="9"
                ry="19"
                transform="rotate(-14 38 25)"
                fill="#FF94B8"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <ellipse
                cx="38"
                cy="26"
                rx="4.5"
                ry="11"
                transform="rotate(-14 38 26)"
                fill="#FFD1E1"
              />
              <ellipse
                cx="82"
                cy="25"
                rx="9"
                ry="19"
                transform="rotate(14 82 25)"
                fill="#FF94B8"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <ellipse
                cx="82"
                cy="26"
                rx="4.5"
                ry="11"
                transform="rotate(14 82 26)"
                fill="#FFD1E1"
              />
            </g>
          )}

          {outfit === "bear_pajama" && (
            <g>
              {/* Cute Round Bear Ears */}
              <circle
                cx="33"
                cy="30"
                r="11"
                fill="#D99B66"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <circle cx="33" cy="30" r="5.5" fill="#FFE5B4" />
              <circle
                cx="87"
                cy="30"
                r="11"
                fill="#D99B66"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <circle cx="87" cy="30" r="5.5" fill="#FFE5B4" />
            </g>
          )}

          {outfit === "starlight_cape" && (
            <g>
              {/* Dreamy Lavender Beret Hat */}
              <ellipse
                cx="62"
                cy="24"
                rx="28"
                ry="12"
                transform="rotate(-8 62 24)"
                fill="#B388FF"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <circle
                cx="62"
                cy="12"
                r="4"
                fill="#FFD84D"
                stroke="#4A3728"
                strokeWidth="2"
              />
            </g>
          )}

          {outfit === "royal_uniform" && (
            <g>
              {/* Royal Academy Beret with Ribbon */}
              <ellipse
                cx="60"
                cy="23"
                rx="26"
                ry="11"
                fill="#3E4A7B"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <path
                d="M48 20L72 20"
                stroke="#FFD84D"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </g>
          )}

          {/* Back Hair */}
          <path
            d="M28 56C24 72 26 92 34 102H86C94 92 96 72 92 56C88 36 76 26 60 26C44 26 32 36 28 56Z"
            fill="#5C4033"
            stroke="#4A3728"
            strokeWidth="2.5"
          />

          {/* Outfit Body / Shoulders */}
          {outfit === "hoodie_pink" && (
            <g>
              <path
                d="M28 118C30 92 42 84 60 84C78 84 90 92 92 118Z"
                fill="#FF7EB3"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              {/* White hoodie drawstrings & star graphic */}
              <path
                d="M53 88V104M67 88V104"
                stroke="#FFFDF7"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <circle cx="53" cy="105" r="2.5" fill="#FFFDF7" />
              <circle cx="67" cy="105" r="2.5" fill="#FFFDF7" />
            </g>
          )}

          {outfit === "starlight_cape" && (
            <g>
              <path
                d="M24 118C26 90 40 83 60 83C80 83 94 90 96 118Z"
                fill="#9B6BFF"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              {/* Fluffy white collar & gold star clasp */}
              <path
                d="M40 86C46 94 74 94 80 86"
                fill="#FFFDF7"
                stroke="#4A3728"
                strokeWidth="2.2"
              />
              <circle
                cx="60"
                cy="95"
                r="5"
                fill="#FFD84D"
                stroke="#4A3728"
                strokeWidth="2"
              />
            </g>
          )}

          {outfit === "y2k_headphone" && (
            <g>
              <path
                d="M28 118C30 92 42 84 60 84C78 84 90 92 92 118Z"
                fill="#4CD4A9"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              {/* Retro Y2K headphones around neck/ears */}
              <ellipse
                cx="26"
                cy="58"
                rx="7"
                ry="11"
                fill="#4CD4A9"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <ellipse
                cx="94"
                cy="58"
                rx="7"
                ry="11"
                fill="#4CD4A9"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
            </g>
          )}

          {outfit === "bear_pajama" && (
            <g>
              <path
                d="M26 118C28 91 41 84 60 84C79 84 92 91 94 118Z"
                fill="#E8A86B"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              <circle
                cx="60"
                cy="102"
                r="10"
                fill="#FFF5D6"
                stroke="#4A3728"
                strokeWidth="2"
              />
            </g>
          )}

          {outfit === "royal_uniform" && (
            <g>
              <path
                d="M27 118C29 91 41 84 60 84C79 84 91 91 93 118Z"
                fill="#3E4A7B"
                stroke="#4A3728"
                strokeWidth="2.5"
              />
              {/* Strawberry Red Ribbon */}
              <path
                d="M52 88L60 95L68 88L65 100L60 95L55 100Z"
                fill="#FF5C8A"
                stroke="#4A3728"
                strokeWidth="2"
              />
            </g>
          )}

          {/* Chibi Face */}
          <rect
            x="33"
            y="34"
            width="54"
            height="50"
            rx="24"
            fill="#FFF0E5"
            stroke="#4A3728"
            strokeWidth="2.5"
          />

          {/* Front Bangs Hair */}
          <path
            d="M32 52C32 35 44 27 60 27C76 27 88 35 88 52C82 44 74 47 68 52C64 43 56 43 52 52C45 46 38 45 32 52Z"
            fill="#6E4B3A"
            stroke="#4A3728"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* Cute Star Hairpin on Bangs */}
          <path
            d="M77 38L79 42L83 43L79 45L77 49L75 45L71 43L75 42L77 38Z"
            fill="#FFD84D"
            stroke="#4A3728"
            strokeWidth="1.5"
          />

          {/* Sparkling Eyes */}
          <ellipse cx="46" cy="60" rx="4.5" ry="5.5" fill="#4A3728" />
          <circle cx="44.5" cy="58" r="1.8" fill="#FFFFFF" />
          <circle cx="47.5" cy="62" r="1" fill="#FFFFFF" />

          <ellipse cx="74" cy="60" rx="4.5" ry="5.5" fill="#4A3728" />
          <circle cx="72.5" cy="58" r="1.8" fill="#FFFFFF" />
          <circle cx="75.5" cy="62" r="1" fill="#FFFFFF" />

          {/* Rosy Kawaii Cheeks */}
          <ellipse cx="38" cy="66" rx="5.5" ry="3.2" fill="#FF94B8" opacity="0.65" />
          <ellipse cx="82" cy="66" rx="5.5" ry="3.2" fill="#FF94B8" opacity="0.65" />

          {/* Happy Cat Smile */}
          <path
            d="M55 67C56.8 70 59.5 70 60 67.5C60.5 70 63.2 70 65 67"
            stroke="#4A3728"
            strokeWidth="2.3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Mini Starlight Stick in Hand */}
          <g transform="translate(82, 76) rotate(14)">
            <rect
              x="4"
              y="12"
              width="6"
              height="18"
              rx="3"
              fill="#FFFDF7"
              stroke="#4A3728"
              strokeWidth="2"
            />
            <circle
              cx="7"
              cy="8"
              r="9"
              fill="#FFE3EC"
              stroke="#4A3728"
              strokeWidth="2"
            />
            <path
              d="M7 2L8.8 6L13 6.5L9.8 9.2L10.8 13.5L7 11L3.2 13.5L4.2 9.2L1 6.5L5.2 6L7 2Z"
              fill="#FF6B9D"
            />
          </g>
        </svg>

        {/* Bottom Polaroid Caption Strip */}
        <div className="absolute bottom-0 inset-x-0 bg-[#FFFDF7]/90 border-t-2 border-[#4A3728] py-0.5 text-center">
          <span className="text-[11px] font-black tracking-tight text-[#4A3728]">
            ★ 星途經紀人 ★
          </span>
        </div>
      </div>

      {/* Level Pill Sticker Badge */}
      {showBadge && (
        <div className="absolute -bottom-2 -right-2 bg-[#FF5C8A] text-white font-mono-num text-xs font-bold px-2.5 py-0.5 rounded-full border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728] z-20">
          Lv.{level}
        </div>
      )}
    </div>
  );
}

export function HandDrawnSticker({
  sticker = "sparkles",
  size = 32,
  className = "",
}: {
  sticker?: string;
  size?: number;
  className?: string;
}) {
  const item =
    STICKER_OPTIONS.find((s) => s.id === sticker) || STICKER_OPTIONS[9];

  return (
    <span
      className={`inline-flex items-center justify-center rounded-2xl border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728] select-none shrink-0 ${className}`}
      style={{
        width: size,
        height: size,
        backgroundColor: item.color,
        fontSize: Math.round(size * 0.54),
      }}
      title={item.label}
    >
      {item.emoji}
    </span>
  );
}
