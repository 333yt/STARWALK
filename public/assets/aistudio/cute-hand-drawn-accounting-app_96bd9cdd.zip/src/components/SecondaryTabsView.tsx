"use client";

import React, { useState } from "react";
import {
  ChibiManagerAvatar,
  HandDrawnSticker,
  OUTFIT_CATALOG,
  STICKER_OPTIONS,
} from "@/components/KawaiiIllustrations";
import {
  Sparkles,
  Plus,
  Trash2,
  Star,
  Gift,
  CheckCircle2,
  Compass,
  Award,
  Heart,
  Ticket,
} from "lucide-react";

export interface ConcertGoalItem {
  id: number;
  title: string;
  artist: string;
  venue: string;
  concertDate: string;
  targetAmount: number;
  allocatedAmount: number;
  seatZone: string;
  ticketColor: string;
  isPrimary: boolean;
  notes: string;
}

export interface TransactionItem {
  id: number;
  date: string;
  type: string;
  groupType: string;
  category: string;
  title: string;
  amount: number;
  sticker: string;
  note: string;
  mood: string;
}

export interface CollectionItem {
  id: number;
  itemType: string;
  title: string;
  idolName: string;
  acquiredDate: string;
  price: number;
  rarity: string;
  sticker: string;
  memo: string;
  colorTheme: string;
}

export interface ManagerProfileData {
  id: number;
  name: string;
  motto: string;
  level: number;
  xp: number;
  xpToNextLevel: number;
  starlightCoins: number;
  currentOutfit: string;
  unlockedOutfits: string;
  baseSavings: number;
  monthlyBudget: number;
  theme: string;
}

const TICKET_BG_MAP: Record<string, string> = {
  strawberry: "#FFF0F5",
  lavender: "#F4EEFF",
  mint: "#E8FBF4",
  butter: "#FFF8DC",
};

export function ConcertJourneyTab({
  goals,
  availableUnallocated,
  onOpenNewGoal,
  onAllocateFund,
  onSetPrimary,
  onDeleteGoal,
}: {
  goals: ConcertGoalItem[];
  availableUnallocated: number;
  onOpenNewGoal: () => void;
  onAllocateFund: (goalId: number, amount: number) => Promise<void>;
  onSetPrimary: (goalId: number) => Promise<void>;
  onDeleteGoal: (goalId: number) => Promise<void>;
}) {
  const [customAmounts, setCustomAmounts] = useState<Record<number, string>>(
    {}
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="sketch-card bg-[#FFF9E6] p-5 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative">
        <div
          className="washi-tape-pink absolute -top-3 left-10 w-24 h-5 rounded-sm"
          style={{ transform: "rotate(-2deg)" }}
        />
        <div className="flex items-center gap-3.5">
          <HandDrawnSticker sticker="ticket" size={48} />
          <div>
            <h2 className="text-xl md:text-2xl font-black text-[#4A3728] flex items-center gap-2">
              🎫 演唱會存錢旅程｜夢想門票存根夾
            </h2>
            <p className="text-xs md:text-sm text-[#8C7365]">
              將每一筆省下的日常開支化為演唱會基金，點亮通往搖滾區第一排的星途地圖！
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 self-end md:self-center">
          <div className="bg-white px-3.5 py-2 rounded-2xl border-2 border-[#4A3728] text-xs font-bold">
            可分配存錢金庫：
            <span className="font-mono-num text-sm font-black text-[#FF5C8A] ml-1">
              NT$ {availableUnallocated.toLocaleString()}
            </span>
          </div>
          <button
            onClick={onOpenNewGoal}
            className="sticker-btn px-5 py-2.5 rounded-full bg-[#FF5C8A] text-white text-sm font-black flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            新增演唱會目標
          </button>
        </div>
      </div>

      {goals.length === 0 ? (
        <div className="sketch-dashed-box p-12 text-center space-y-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#FFE3EC] border-2 border-[#4A3728] shadow-[3px_3px_0px_#4A3728] flex items-center justify-center">
            <Compass className="w-8 h-8 text-[#FF5C8A]" />
          </div>
          <h3 className="text-lg font-black text-[#4A3728]">
            尚未建立任何演唱會目標
          </h3>
          <p className="text-sm text-[#8C7365] max-w-md mx-auto">
            設定你想參加的下一場偶像舞台、粉絲見面會或跨國巡演，啟動專屬手繪存錢門票！
          </p>
          <button
            onClick={onOpenNewGoal}
            className="sticker-btn px-6 py-3 rounded-full bg-[#FF5C8A] text-white text-sm font-black inline-flex items-center gap-2"
          >
            + 建立第一個演唱會目標
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {goals.map((g) => {
            const pct = Math.min(
              100,
              Math.round((g.allocatedAmount / Math.max(1, g.targetAmount)) * 100)
            );
            const remaining = Math.max(0, g.targetAmount - g.allocatedAmount);
            const bg = TICKET_BG_MAP[g.ticketColor] || "#FFF0F5";

            return (
              <div
                key={g.id}
                style={{ backgroundColor: bg }}
                className="sketch-card p-6 relative overflow-hidden flex flex-col justify-between"
              >
                {/* Ticket Notch Cutouts */}
                <div className="w-6 h-6 rounded-full bg-[#FFFDF7] border-2 border-[#4A3728] absolute -left-3.5 top-1/2 -translate-y-1/2" />
                <div className="w-6 h-6 rounded-full bg-[#FFFDF7] border-2 border-[#4A3728] absolute -right-3.5 top-1/2 -translate-y-1/2" />

                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex flex-wrap items-center gap-2">
                      {g.isPrimary ? (
                        <span className="px-3 py-0.5 rounded-full bg-[#FF5C8A] text-white text-xs font-black border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728]">
                          ★ 首頁主要目標
                        </span>
                      ) : (
                        <button
                          onClick={() => onSetPrimary(g.id)}
                          className="px-3 py-0.5 rounded-full bg-white text-[#4A3728] text-xs font-bold border-2 border-[#4A3728] hover:bg-[#FFF3B0] cursor-pointer"
                        >
                          設為首頁主要目標
                        </button>
                      )}
                      <span className="px-2.5 py-0.5 rounded-full bg-white/90 text-[#4A3728] text-xs font-bold border border-[#4A3728]">
                        💺 {g.seatZone}
                      </span>
                    </div>
                    <button
                      onClick={() => onDeleteGoal(g.id)}
                      className="text-[#8C7365] hover:text-[#FF5C77] p-1 cursor-pointer"
                      title="刪除此目標"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <h3 className="text-lg font-black text-[#4A3728] mb-1">
                    {g.title}
                  </h3>
                  <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-[#8C7365] mb-4">
                    <span>🎤 {g.artist}</span>
                    <span>📍 {g.venue}</span>
                    <span className="font-mono-num text-[#4A3728] bg-white/80 px-2 py-0.5 rounded-md border border-[#4A3728]">
                      📅 {g.concertDate}
                    </span>
                  </div>

                  {/* Savings Progress */}
                  <div className="bg-white/90 p-4 rounded-2xl border-2 border-[#4A3728] mb-4">
                    <div className="flex items-baseline justify-between mb-1.5">
                      <span className="text-xs font-black text-[#8C7365]">
                        目前已存演唱會基金 ({pct}%)
                      </span>
                      <div className="font-mono-num text-base font-black text-[#4A3728]">
                        <span className="text-[#FF5C8A]">
                          NT$ {g.allocatedAmount.toLocaleString()}
                        </span>{" "}
                        / NT$ {g.targetAmount.toLocaleString()}
                      </div>
                    </div>

                    <div className="w-full h-4 rounded-full bg-[#F5EBE1] border-2 border-[#4A3728] overflow-hidden p-0.5">
                      <div
                        className="h-full rounded-full crayon-stripe-pink transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>

                    {/* 4 Stage Milestones */}
                    <div className="grid grid-cols-4 gap-1 mt-3 text-[11px] font-bold text-center">
                      {[
                        { step: 25, label: "25% 搶票預備" },
                        { step: 50, label: "50% 手燈周邊" },
                        { step: 75, label: "75% 應援交通" },
                        { step: 100, label: "100% 搖滾圓夢" },
                      ].map((m) => (
                        <div
                          key={m.step}
                          className={`py-1 px-1 rounded-lg border ${
                            pct >= m.step
                              ? "bg-[#FFF0B8] border-[#4A3728] text-[#4A3728]"
                              : "bg-white/50 border-dashed border-[#C7B299] text-[#8C7365]"
                          }`}
                        >
                          {pct >= m.step ? "★ " : "○ "}
                          {m.label}
                        </div>
                      ))}
                    </div>
                  </div>

                  {g.notes && (
                    <p className="text-xs text-[#6E5646] bg-white/70 px-3 py-2 rounded-xl border border-dashed border-[#BFA592] mb-4">
                      📌 手帳備註：{g.notes}
                    </p>
                  )}
                </div>

                {/* Perforated Divider & Quick Fund Allocation */}
                <div className="border-t-2 border-dashed border-[#4A3728]/40 pt-4 mt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="text-xs font-bold text-[#4A3728]">
                    {remaining === 0 ? (
                      <span className="text-[#2BB58A] font-black">
                        🎉 恭喜達成目標！準備出發看本命！
                      </span>
                    ) : (
                      <span>
                        距離目標還差{" "}
                        <strong className="font-mono-num text-[#FF5C8A]">
                          NT$ {remaining.toLocaleString()}
                        </strong>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onAllocateFund(g.id, 500)}
                      className="sticker-btn px-3 py-1.5 rounded-full bg-[#FFF0B8] text-xs font-black text-[#4A3728]"
                    >
                      + 存 $500
                    </button>
                    <button
                      onClick={() => onAllocateFund(g.id, 1000)}
                      className="sticker-btn px-3 py-1.5 rounded-full bg-[#B8F2DC] text-xs font-black text-[#4A3728]"
                    >
                      + 存 $1,000
                    </button>
                    <div className="flex items-center">
                      <input
                        type="number"
                        placeholder="自訂$"
                        value={customAmounts[g.id] || ""}
                        onChange={(e) =>
                          setCustomAmounts({
                            ...customAmounts,
                            [g.id]: e.target.value,
                          })
                        }
                        className="w-20 px-2 py-1 rounded-l-xl border-2 border-[#4A3728] bg-white text-xs font-mono-num font-bold"
                      />
                      <button
                        onClick={() => {
                          const val = Number(customAmounts[g.id]);
                          if (val > 0) {
                            onAllocateFund(g.id, val);
                            setCustomAmounts({ ...customAmounts, [g.id]: "" });
                          }
                        }}
                        className="px-2.5 py-1 rounded-r-xl border-y-2 border-r-2 border-[#4A3728] bg-[#FF5C8A] text-white text-xs font-black cursor-pointer"
                      >
                        撥款
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function AnalyticsTab({
  transactions,
  monthlyBudget,
  allocatedConcertFund,
}: {
  transactions: TransactionItem[];
  monthlyBudget: number;
  allocatedConcertFund: number;
}) {
  const expenses = transactions.filter((t) => t.type === "expense");
  const incomes = transactions.filter((t) => t.type === "income");

  const idolTotal = expenses
    .filter((t) => t.groupType === "idol")
    .reduce((acc, t) => acc + t.amount, 0);
  const dailyTotal = expenses
    .filter((t) => t.groupType === "daily")
    .reduce((acc, t) => acc + t.amount, 0);
  const totalExpense = idolTotal + dailyTotal;
  const totalIncome = incomes.reduce((acc, t) => acc + t.amount, 0);

  const idolRatio =
    totalExpense > 0 ? Math.round((idolTotal / totalExpense) * 100) : 0;
  const dailyRatio = totalExpense > 0 ? 100 - idolRatio : 0;

  // Group by category
  const categoryTotals: Record<
    string,
    { amount: number; sticker: string; group: string }
  > = {};
  for (const t of expenses) {
    if (!categoryTotals[t.category]) {
      categoryTotals[t.category] = {
        amount: 0,
        sticker: t.sticker,
        group: t.groupType,
      };
    }
    categoryTotals[t.category].amount += t.amount;
  }
  const sortedCategories = Object.entries(categoryTotals).sort(
    (a, b) => b[1].amount - a[1].amount
  );

  return (
    <div className="space-y-6">
      {/* Top Summary Postcards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="sketch-card bg-[#FFEBF2] p-5 relative">
          <div className="text-xs font-black text-[#8C7365] mb-1">
            🎤 追星應援總支出
          </div>
          <div className="font-mono-num text-2xl font-black text-[#FF5C8A]">
            NT$ {idolTotal.toLocaleString()}
          </div>
          <div className="text-xs font-bold text-[#4A3728] mt-1">
            佔總支出 {idolRatio}%・每一分都是愛 💖
          </div>
        </div>

        <div className="sketch-card bg-[#FFF5D6] p-5 relative">
          <div className="text-xs font-black text-[#8C7365] mb-1">
            🍱 日常生活總支出
          </div>
          <div className="font-mono-num text-2xl font-black text-[#E58A28]">
            NT$ {dailyTotal.toLocaleString()}
          </div>
          <div className="text-xs font-bold text-[#4A3728] mt-1">
            佔總支出 {dailyRatio}%・好好吃飯努力生活
          </div>
        </div>

        <div className="sketch-card bg-[#E6FAF2] p-5 relative">
          <div className="text-xs font-black text-[#8C7365] mb-1">
            💰 累計收入與出卡回血
          </div>
          <div className="font-mono-num text-2xl font-black text-[#2BB58A]">
            NT$ {totalIncome.toLocaleString()}
          </div>
          <div className="text-xs font-bold text-[#4A3728] mt-1">
            共 {incomes.length} 筆入帳補充金庫
          </div>
        </div>

        <div className="sketch-card bg-[#F2EAFF] p-5 relative">
          <div className="text-xs font-black text-[#8C7365] mb-1">
            💎 已鎖定演唱會儲蓄
          </div>
          <div className="font-mono-num text-2xl font-black text-[#8A5CF5]">
            NT$ {allocatedConcertFund.toLocaleString()}
          </div>
          <div className="text-xs font-bold text-[#4A3728] mt-1">
            專款專用・守護搖滾區門票
          </div>
        </div>
      </div>

      {/* Two Column Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Category Breakdown Hand-Drawn Bars */}
        <div className="lg:col-span-7 sketch-card bg-white p-6 relative">
          <div
            className="washi-tape-yellow absolute -top-3 left-12 w-28 h-5 rounded-sm"
            style={{ transform: "rotate(-2deg)" }}
          />
          <h3 className="text-lg font-black text-[#4A3728] mb-1">
            📊 手繪分類排行｜錢錢都變成什麼可愛的樣子了？
          </h3>
          <p className="text-xs text-[#8C7365] mb-5">
            依消費分類統計你的手帳印章紀錄
          </p>

          {sortedCategories.length === 0 ? (
            <div className="sketch-dashed-box p-10 text-center text-sm font-bold text-[#8C7365]">
              目前尚無支出紀錄，快去記一筆帳看看分析圖表吧！🌟
            </div>
          ) : (
            <div className="space-y-4">
              {sortedCategories.map(([cat, info]) => {
                const pct = Math.max(
                  6,
                  Math.round((info.amount / Math.max(1, totalExpense)) * 100)
                );
                return (
                  <div key={cat} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm font-black">
                      <div className="flex items-center gap-2">
                        <HandDrawnSticker sticker={info.sticker} size={28} />
                        <span>{cat}</span>
                        <span
                          className={`text-[11px] px-2 py-0.5 rounded-full border border-[#4A3728] ${
                            info.group === "idol"
                              ? "bg-[#FFE3EC] text-[#FF5C8A]"
                              : "bg-[#FFF3C4] text-[#4A3728]"
                          }`}
                        >
                          {info.group === "idol" ? "追星" : "日常"}
                        </span>
                      </div>
                      <div className="font-mono-num">
                        NT$ {info.amount.toLocaleString()}{" "}
                        <span className="text-xs text-[#8C7365]">({pct}%)</span>
                      </div>
                    </div>
                    <div className="w-full h-3.5 rounded-full bg-[#F7EFE6] border-2 border-[#4A3728] overflow-hidden p-0.5">
                      <div
                        className={`h-full rounded-full ${
                          info.group === "idol"
                            ? "crayon-stripe-pink"
                            : "crayon-stripe-mint"
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Idol vs Daily Balance & Manager Advice */}
        <div className="lg:col-span-5 sketch-card bg-[#FFFDF7] p-6 flex flex-col justify-between space-y-5">
          <div>
            <h3 className="text-lg font-black text-[#4A3728] mb-1">
              ⚖️ 追星與生活平衡天秤
            </h3>
            <p className="text-xs text-[#8C7365] mb-4">
              維持健康的日常預算，才能長長久久快樂追星！
            </p>

            {/* Dual Ratio Bar */}
            <div className="p-4 rounded-2xl bg-white border-2 border-[#4A3728] space-y-3">
              <div className="flex justify-between text-xs font-black">
                <span className="text-[#FF5C8A]">
                  🎤 追星消費 ({idolRatio}%)
                </span>
                <span className="text-[#2BB58A]">
                  🍱 日常生活 ({dailyRatio}%)
                </span>
              </div>
              <div className="w-full h-6 rounded-full border-2 border-[#4A3728] overflow-hidden flex bg-[#F5EBE1]">
                <div
                  className="h-full crayon-stripe-pink transition-all"
                  style={{ width: `${idolRatio || 50}%` }}
                />
                <div
                  className="h-full crayon-stripe-mint transition-all"
                  style={{ width: `${dailyRatio || 50}%` }}
                />
              </div>
              <div className="text-xs text-[#6E5646] leading-relaxed pt-1">
                本月預算上限為{" "}
                <strong className="font-mono-num">
                  NT$ {monthlyBudget.toLocaleString()}
                </strong>
                ，目前已使用{" "}
                <strong className="font-mono-num text-[#FF5C8A]">
                  {Math.round(
                    (totalExpense / Math.max(1, monthlyBudget)) * 100
                  )}
                  %
                </strong>
                。
              </div>
            </div>
          </div>

          {/* Cute Manager Tip Box */}
          <div className="bg-[#FFEBF2] p-4 rounded-2xl border-2 border-[#4A3728] flex items-center gap-3.5">
            <ChibiManagerAvatar size={72} showBadge={false} />
            <div className="text-xs space-y-1">
              <div className="font-black text-[#FF5C8A] text-sm">
                💡 星途經紀人小叮嚀：
              </div>
              <p className="text-[#4A3728] font-medium leading-relaxed">
                {idolRatio > 60
                  ? "本月本命回歸周邊買得很開心對吧！別忘了接下來幾天多吃點平價便當平衡一下預算唷 🍱✨"
                  : "目前的日常與追星支出比例超完美！省下的手搖飲錢剛好可以再撥款 NT$ 500 進演唱會基金！🎫"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function CollectionBookTab({
  collections,
  onAddCollection,
  onDeleteCollection,
}: {
  collections: CollectionItem[];
  onAddCollection: (item: {
    itemType: string;
    title: string;
    idolName: string;
    acquiredDate: string;
    price: number;
    rarity: string;
    sticker: string;
    memo: string;
    colorTheme: string;
  }) => Promise<void>;
  onDeleteCollection: (id: number) => Promise<void>;
}) {
  const [showForm, setShowForm] = useState(false);
  const [filterType, setFilterType] = useState("all");
  const [title, setTitle] = useState("");
  const [idolName, setIdolName] = useState("LUNA 露娜");
  const [itemType, setItemType] = useState("photocard");
  const [price, setPrice] = useState("450");
  const [rarity, setRarity] = useState("SSR 本命神卡");
  const [sticker, setSticker] = useState("photocard");
  const [memo, setMemo] = useState("");

  const filtered = collections.filter((c) =>
    filterType === "all" ? true : c.itemType === filterType
  );

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    await onAddCollection({
      itemType,
      title,
      idolName,
      acquiredDate: "2026-11-04",
      price: Number(price) || 0,
      rarity,
      sticker,
      memo,
      colorTheme: "strawberry",
    });
    setTitle("");
    setMemo("");
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="sketch-card bg-[#FFEBF2] p-5 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <HandDrawnSticker sticker="photocard" size={48} />
          <div>
            <h2 className="text-xl md:text-2xl font-black text-[#4A3728]">
              💖 追星收藏冊｜九宮格本命卡冊與周邊展示櫃
            </h2>
            <p className="text-xs md:text-sm text-[#8C7365]">
              每一張小卡、手燈與專輯都是無價的青春星途收藏！
            </p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="sticker-btn px-5 py-2.5 rounded-full bg-[#FF5C8A] text-white text-sm font-black flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          收錄新小卡 / 周邊
        </button>
      </div>

      {/* Filter Pills */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: "all", label: "✨ 全部收藏" },
          { id: "photocard", label: "🃏 本命小卡" },
          { id: "album", label: "💿 正規專輯" },
          { id: "lightstick", label: "🎤 應援手燈" },
          { id: "memory_ticket", label: "🎟️ 紀念票根" },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id)}
            className={`sticker-btn-soft px-4 py-1.5 rounded-full text-xs font-black ${
              filterType === f.id
                ? "bg-[#4A3728] text-white"
                : "bg-white text-[#4A3728]"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {showForm && (
        <form
          onSubmit={handleCreate}
          className="sketch-card bg-[#FFFDF7] p-5 space-y-4 animate-stamp"
        >
          <h3 className="text-base font-black text-[#4A3728]">
            ✨ 將新寶貝收進九宮格卡冊 (+20 XP / +30 P)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="收藏名稱（例：眨眼特典閃卡）"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
              required
            />
            <input
              type="text"
              placeholder="本命成員（例：LUNA）"
              value={idolName}
              onChange={(e) => setIdolName(e.target.value)}
              className="px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
            />
            <input
              type="number"
              placeholder="購入價格 NT$"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-sm font-bold"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <select
              value={itemType}
              onChange={(e) => {
                setItemType(e.target.value);
                if (e.target.value === "photocard") setSticker("photocard");
                if (e.target.value === "album") setSticker("album");
                if (e.target.value === "lightstick") setSticker("lightstick");
                if (e.target.value === "memory_ticket") setSticker("ticket");
              }}
              className="px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
            >
              <option value="photocard">🃏 本命小卡</option>
              <option value="album">💿 正規專輯</option>
              <option value="lightstick">🎤 應援手燈</option>
              <option value="memory_ticket">🎟️ 紀念票根</option>
            </select>
            <select
              value={rarity}
              onChange={(e) => setRarity(e.target.value)}
              className="px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
            >
              <option value="SSR 本命神卡">🌟 SSR 本命神卡</option>
              <option value="SR 特典閃卡">✨ SR 特典閃卡</option>
              <option value="限定收藏">💖 限定收藏</option>
            </select>
            <input
              type="text"
              placeholder="收藏心情小筆記..."
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="sticker-btn-soft px-4 py-1.5 rounded-full bg-white text-xs font-bold"
            >
              取消
            </button>
            <button
              type="submit"
              className="sticker-btn px-5 py-1.5 rounded-full bg-[#FF5C8A] text-white text-xs font-black"
            >
              裝進卡套收錄！
            </button>
          </div>
        </form>
      )}

      {/* Polaroid Grid */}
      {filtered.length === 0 ? (
        <div className="sketch-dashed-box p-12 text-center space-y-3">
          <Heart className="w-10 h-10 text-[#FF5C8A] mx-auto" />
          <div className="text-base font-black">卡冊目前空空的唷！</div>
          <p className="text-xs text-[#8C7365]">
            點擊右上角「收錄新小卡 / 周邊」，把你最愛的本命小卡貼進手帳裡吧！
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filtered.map((item, idx) => (
            <div
              key={item.id}
              className="sketch-card bg-white p-4 flex flex-col justify-between relative group hover:-translate-y-1 transition-transform"
            >
              <div
                className={`washi-tape-${
                  idx % 2 === 0 ? "pink" : "yellow"
                } absolute -top-2.5 left-1/2 -translate-x-1/2 w-20 h-4 rounded-sm`}
                style={{
                  transform: `translateX(-50%) rotate(${
                    idx % 2 === 0 ? -3 : 3
                  }deg)`,
                }}
              />

              <div>
                {/* Polaroid Photo Window */}
                <div className="h-36 rounded-2xl border-2 border-[#4A3728] bg-gradient-to-br from-[#FFEBF2] via-[#FFF8E7] to-[#EFE6FF] flex flex-col items-center justify-center relative mb-3 overflow-hidden">
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-[#FFF0B8] border border-[#4A3728] text-[10px] font-black">
                    {item.rarity}
                  </span>
                  <button
                    onClick={() => onDeleteCollection(item.id)}
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-full bg-white/80 text-[#FF5C77] cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <HandDrawnSticker sticker={item.sticker} size={56} />
                  <span className="text-xs font-black text-[#4A3728] mt-2 bg-white/90 px-2.5 py-0.5 rounded-full border border-[#4A3728]">
                    ♥ {item.idolName} ♥
                  </span>
                </div>

                <h4 className="font-black text-sm text-[#4A3728] line-clamp-1 mb-1">
                  {item.title}
                </h4>
                <p className="text-xs text-[#8C7365] line-clamp-2 mb-3">
                  {item.memo || "珍藏於星途卡冊 ✨"}
                </p>
              </div>

              <div className="flex items-center justify-between border-t border-dashed border-[#E5D5C5] pt-2.5 text-xs font-bold">
                <span className="font-mono-num text-[#8C7365]">
                  {item.acquiredDate}
                </span>
                <span className="font-mono-num font-black text-[#FF5C8A]">
                  NT$ {item.price.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function CharacterQuestsTab({
  profile,
  onSelectOutfit,
  onUnlockOutfit,
  onClaimQuest,
}: {
  profile: ManagerProfileData;
  onSelectOutfit: (outfitId: string) => Promise<void>;
  onUnlockOutfit: (outfitId: string, cost: number) => Promise<void>;
  onClaimQuest: (xp: number, coins: number, questId: string) => Promise<void>;
}) {
  const [claimedQuests, setClaimedQuests] = useState<string[]>([]);

  let unlockedList: string[] = ["hoodie_pink"];
  try {
    unlockedList = JSON.parse(profile.unlockedOutfits);
  } catch {
    unlockedList = ["hoodie_pink"];
  }

  const quests = [
    {
      id: "q1",
      title: "✍️ 完成今日第一筆手帳記帳",
      desc: "養成每天記錄日常與追星開銷的好習慣",
      xp: 25,
      coins: 40,
      sticker: "sparkles",
    },
    {
      id: "q2",
      title: "🧋 少喝一杯手搖飲・省錢挑戰",
      desc: "把省下的飲料錢轉入演唱會搖滾區基金！",
      xp: 35,
      coins: 50,
      sticker: "boba",
    },
    {
      id: "q3",
      title: "🃏 整理九宮格小卡收藏冊",
      desc: "清點手邊的專卡與特典卡，避免重複購買",
      xp: 30,
      coins: 45,
      sticker: "photocard",
    },
    {
      id: "q4",
      title: "🎫 檢查本月演唱會存錢進度",
      desc: "確認離目標座位還差多少預算",
      xp: 40,
      coins: 60,
      sticker: "ticket",
    },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left: Chibi Manager Dressing Room */}
      <div className="lg:col-span-7 sketch-card bg-[#FFFDF7] p-6 relative">
        <div
          className="washi-tape-pink absolute -top-3 left-10 w-28 h-5 rounded-sm"
          style={{ transform: "rotate(-2deg)" }}
        />

        <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
          <div>
            <h3 className="text-xl font-black text-[#4A3728]">
              👗 星途經紀人換裝間｜手繪造型衣櫥
            </h3>
            <p className="text-xs text-[#8C7365]">
              使用記帳獲得的「經紀星光幣 (P)」解鎖超可愛的應援穿搭！
            </p>
          </div>
          <div className="px-3.5 py-1.5 rounded-full bg-[#FFF0B8] border-2 border-[#4A3728] shadow-[2px_2px_0px_#4A3728] text-xs font-black flex items-center gap-1.5">
            ✨ 經紀星光幣：
            <span className="font-mono-num text-sm text-[#FF5C8A]">
              {profile.starlightCoins} P
            </span>
          </div>
        </div>

        {/* Big Avatar Stage Preview */}
        <div className="bg-gradient-to-r from-[#FFEBF2] via-[#FFF9E6] to-[#F2EAFF] p-5 rounded-3xl border-2 border-[#4A3728] flex flex-col sm:flex-row items-center gap-5 mb-5">
          <ChibiManagerAvatar
            outfit={profile.currentOutfit}
            size={132}
            level={profile.level}
          />
          <div className="space-y-2 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white border-2 border-[#4A3728] text-xs font-black text-[#FF5C8A]">
              ★ 目前穿搭：
              {OUTFIT_CATALOG.find((o) => o.id === profile.currentOutfit)?.name}
            </div>
            <h4 className="text-lg font-black text-[#4A3728]">
              {profile.name}（Lv.{profile.level}）
            </h4>
            <p className="text-xs text-[#6E5646]">
              {OUTFIT_CATALOG.find((o) => o.id === profile.currentOutfit)?.desc}
            </p>
            <div className="pt-1">
              <div className="text-[11px] font-bold text-[#8C7365] mb-1">
                成長經驗值：{profile.xp} / {profile.xpToNextLevel} XP
              </div>
              <div className="w-56 max-w-full h-3 rounded-full bg-white border-2 border-[#4A3728] overflow-hidden p-0.5 mx-auto sm:mx-0">
                <div
                  className="h-full rounded-full crayon-stripe-pink"
                  style={{
                    width: `${Math.min(
                      100,
                      Math.round((profile.xp / profile.xpToNextLevel) * 100)
                    )}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Outfit Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {OUTFIT_CATALOG.map((outfit) => {
            const isUnlocked = unlockedList.includes(outfit.id);
            const isEquipped = profile.currentOutfit === outfit.id;

            return (
              <div
                key={outfit.id}
                className={`p-3.5 rounded-2xl border-2 border-[#4A3728] flex items-center justify-between gap-3 transition-all ${
                  isEquipped
                    ? "bg-[#FFE3EC] shadow-[3px_3px_0px_#4A3728]"
                    : "bg-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  <ChibiManagerAvatar
                    outfit={outfit.id}
                    size={58}
                    showBadge={false}
                  />
                  <div>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#FFF5D6] border border-[#4A3728]">
                      {outfit.tag}
                    </span>
                    <div className="font-black text-sm text-[#4A3728] mt-0.5">
                      {outfit.name}
                    </div>
                  </div>
                </div>

                {isEquipped ? (
                  <span className="px-3 py-1.5 rounded-full bg-[#4A3728] text-white text-xs font-black shrink-0">
                    穿戴中 ✓
                  </span>
                ) : isUnlocked ? (
                  <button
                    onClick={() => onSelectOutfit(outfit.id)}
                    className="sticker-btn px-3.5 py-1.5 rounded-full bg-white text-xs font-black text-[#4A3728] shrink-0"
                  >
                    換上穿搭
                  </button>
                ) : (
                  <button
                    onClick={() => onUnlockOutfit(outfit.id, outfit.cost)}
                    disabled={profile.starlightCoins < outfit.cost}
                    className="sticker-btn px-3 py-1.5 rounded-full bg-[#FFF0B8] text-xs font-black text-[#4A3728] disabled:opacity-50 shrink-0"
                  >
                    🔓 {outfit.cost} P
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Daily Fan Quests */}
      <div className="lg:col-span-5 sketch-card bg-white p-6 space-y-4">
        <div className="flex items-center gap-2.5">
          <HandDrawnSticker sticker="sparkles" size={40} />
          <div>
            <h3 className="text-lg font-black text-[#4A3728]">
              🎮 經紀人養成任務板
            </h3>
            <p className="text-xs text-[#8C7365]">
              完成追星省錢挑戰，領取經驗值與星光幣！
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {quests.map((q) => {
            const done = claimedQuests.includes(q.id);
            return (
              <div
                key={q.id}
                className="p-4 rounded-2xl border-2 border-[#4A3728] bg-[#FFFDF7] flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <HandDrawnSticker sticker={q.sticker} size={38} />
                  <div>
                    <div className="text-sm font-black text-[#4A3728]">
                      {q.title}
                    </div>
                    <div className="text-xs text-[#8C7365]">{q.desc}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[11px] font-mono-num font-bold text-[#FF5C8A]">
                        +{q.xp} XP
                      </span>
                      <span className="text-[11px] font-mono-num font-bold text-[#E58A28]">
                        +{q.coins} P
                      </span>
                    </div>
                  </div>
                </div>

                {done ? (
                  <span className="px-3 py-1.5 rounded-full bg-[#E4FBF0] border-2 border-[#4A3728] text-xs font-black text-[#2BB58A] flex items-center gap-1 shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    已領取
                  </span>
                ) : (
                  <button
                    onClick={async () => {
                      setClaimedQuests([...claimedQuests, q.id]);
                      await onClaimQuest(q.xp, q.coins, q.id);
                    }}
                    className="sticker-btn px-3.5 py-1.5 rounded-full bg-[#FF5C8A] text-white text-xs font-black shrink-0 flex items-center gap-1"
                  >
                    <Gift className="w-3.5 h-3.5" />
                    領取獎勵
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function MemoryHallTab({
  collections,
  goals,
  onSwitchToCollection,
}: {
  collections: CollectionItem[];
  goals: ConcertGoalItem[];
  onSwitchToCollection: () => void;
}) {
  return (
    <div className="space-y-6">
      <div className="sketch-card bg-gradient-to-r from-[#F4EEFF] via-[#FFEBF2] to-[#FFF8DC] p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <HandDrawnSticker sticker="heart" size={48} />
          <div>
            <h2 className="text-xl md:text-2xl font-black text-[#4A3728]">
              🎟️ 星途回憶館｜每一場見面的剪貼簿時光機
            </h2>
            <p className="text-xs md:text-sm text-[#8C7365]">
              記帳是工具，收藏是回憶！在這裡重溫你與偶像共度的每一個閃耀瞬間。
            </p>
          </div>
        </div>
        <button
          onClick={onSwitchToCollection}
          className="sticker-btn px-5 py-2.5 rounded-full bg-[#4A3728] text-white text-xs font-black flex items-center gap-1.5"
        >
          <Ticket className="w-4 h-4 text-[#FFD84D]" />
          前往收藏冊新增票根
        </button>
      </div>

      {/* Scrapbook Timeline */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((g) => (
          <div
            key={`goal-${g.id}`}
            className="sketch-card bg-white p-5 relative"
          >
            <div
              className="washi-tape-mint absolute -top-3 right-8 w-24 h-5 rounded-sm"
              style={{ transform: "rotate(3deg)" }}
            />
            <div className="flex items-center gap-2 text-xs font-black text-[#FF5C8A] mb-2">
              <Star className="w-4 h-4 fill-[#FF5C8A]" />
              未來星途預定舞台・{g.concertDate}
            </div>
            <h3 className="text-lg font-black text-[#4A3728] mb-1">
              {g.title}
            </h3>
            <p className="text-xs font-bold text-[#8C7365] mb-3">
              🎤 {g.artist} ｜ 📍 {g.venue} ({g.seatZone})
            </p>
            <div className="p-3 rounded-xl bg-[#FFF8EB] border border-dashed border-[#BFA592] text-xs text-[#4A3728]">
              💎 目前已為這場舞台存下{" "}
              <strong className="font-mono-num text-[#FF5C8A]">
                NT$ {g.allocatedAmount.toLocaleString()}
              </strong>{" "}
              （目標 NT$ {g.targetAmount.toLocaleString()}）
            </div>
          </div>
        ))}

        {collections.map((c) => (
          <div
            key={`col-${c.id}`}
            className="sketch-card bg-[#FFFDF7] p-5 relative"
          >
            <div
              className="washi-tape-pink absolute -top-3 left-8 w-24 h-5 rounded-sm"
              style={{ transform: "rotate(-2deg)" }}
            />
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-[#8A5CF5] flex items-center gap-1">
                <Award className="w-4 h-4" />
                珍藏回憶・{c.acquiredDate}
              </span>
              <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-[#FFE3EC] border border-[#4A3728]">
                {c.rarity}
              </span>
            </div>
            <div className="flex items-start gap-3.5">
              <HandDrawnSticker sticker={c.sticker} size={46} />
              <div>
                <h3 className="text-base font-black text-[#4A3728]">
                  {c.title}
                </h3>
                <div className="text-xs font-bold text-[#8C7365] mb-1.5">
                  本命對象：{c.idolName} ｜ 紀念價值 NT${" "}
                  {c.price.toLocaleString()}
                </div>
                <p className="text-xs text-[#4A3728] bg-white p-2.5 rounded-xl border border-[#E5D5C5]">
                  「{c.memo}」
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
