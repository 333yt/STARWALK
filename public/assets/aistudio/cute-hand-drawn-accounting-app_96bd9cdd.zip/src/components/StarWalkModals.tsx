"use client";

import React, { useState, useEffect } from "react";
import {
  STICKER_OPTIONS,
  HandDrawnSticker,
} from "@/components/KawaiiIllustrations";
import { X, Sparkles, Plus, Check } from "lucide-react";

interface QuickRecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultDate: string;
  onSubmit: (data: {
    date: string;
    type: "expense" | "income";
    groupType: "daily" | "idol" | "income";
    category: string;
    title: string;
    amount: number;
    sticker: string;
    note: string;
    mood: string;
  }) => Promise<void>;
}

const CATEGORY_MAP = {
  idol: [
    { label: "專輯小卡", sticker: "photocard" },
    { label: "官方周邊", sticker: "lightstick" },
    { label: "演唱會門票", sticker: "ticket" },
    { label: "應援集資", sticker: "heart" },
    { label: "音源會員", sticker: "album" },
  ],
  daily: [
    { label: "餐飲美食", sticker: "bento" },
    { label: "手搖飲甜點", sticker: "boba" },
    { label: "交通通勤", sticker: "train" },
    { label: "手帳日用", sticker: "sparkles" },
    { label: "下午茶聚會", sticker: "cake" },
  ],
  income: [
    { label: "薪資零用錢", sticker: "coin" },
    { label: "二手出卡回血", sticker: "photocard" },
    { label: "打工獎金", sticker: "sparkles" },
  ],
};

export function QuickRecordModal({
  isOpen,
  onClose,
  defaultDate,
  onSubmit,
}: QuickRecordModalProps) {
  const [date, setDate] = useState(defaultDate || "2026-11-04");
  const [groupType, setGroupType] = useState<"idol" | "daily" | "income">(
    "idol"
  );
  const [category, setCategory] = useState("專輯小卡");
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [sticker, setSticker] = useState("photocard");
  const [note, setNote] = useState("");
  const [mood, setMood] = useState("excited");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (defaultDate) setDate(defaultDate);
  }, [defaultDate]);

  if (!isOpen) return null;

  const handleGroupSwitch = (g: "idol" | "daily" | "income") => {
    setGroupType(g);
    const first = CATEGORY_MAP[g][0];
    setCategory(first.label);
    setSticker(first.sticker);
  };

  const applyQuickPreset = (preset: {
    g: "idol" | "daily" | "income";
    cat: string;
    title: string;
    amt: number;
    stk: string;
    note: string;
  }) => {
    setGroupType(preset.g);
    setCategory(preset.cat);
    setTitle(preset.title);
    setAmount(String(preset.amt));
    setSticker(preset.stk);
    setNote(preset.note);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return;
    setSubmitting(true);
    try {
      await onSubmit({
        date,
        type: groupType === "income" ? "income" : "expense",
        groupType,
        category,
        title: title.trim() || `${category}紀錄`,
        amount: Number(amount),
        sticker,
        note,
        mood,
      });
      setTitle("");
      setAmount("");
      setNote("");
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#4A3728]/45 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="sketch-card relative w-full max-w-lg bg-[#FFFDF7] p-6 md:p-7 my-8 animate-stamp">
        {/* Decorative Washi Tape */}
        <div
          className="washi-tape-pink absolute -top-3.5 left-1/2 -translate-x-1/2 w-32 h-6 rounded-sm"
          style={{ transform: "translateX(-50%) rotate(-2deg)" }}
        />

        <div className="flex items-center justify-between border-b-2 border-dashed border-[#E5D5C5] pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <HandDrawnSticker sticker={sticker} size={40} />
            <div>
              <h3 className="text-xl font-black text-[#4A3728] flex items-center gap-1.5">
                ✍️ 手帳快速記一筆
                <span className="text-xs font-bold bg-[#FFF3B0] text-[#4A3728] px-2 py-0.5 rounded-full border border-[#4A3728]">
                  +15 XP / +25 P
                </span>
              </h3>
              <p className="text-xs text-[#8C7365]">
                蓋下今日的小印章，離下一場演唱會更近一步！
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="sticker-btn w-9 h-9 rounded-full bg-[#FFE3EC] flex items-center justify-center text-[#4A3728]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* One-Click Quick Presets for Fast Demo */}
        <div className="mb-4">
          <div className="text-xs font-bold text-[#8C7365] mb-1.5 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#FF5C8A]" />
            一鍵帶入常用手帳貼紙：
          </div>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() =>
                applyQuickPreset({
                  g: "idol",
                  cat: "專輯小卡",
                  title: "購入本命特典閃卡",
                  amt: 450,
                  stk: "photocard",
                  note: "卡面超美值得珍藏 ✨",
                })
              }
              className="text-xs font-bold px-2.5 py-1 rounded-full bg-[#FFE8F0] hover:bg-[#FFD4E4] text-[#4A3728] border border-[#4A3728] cursor-pointer"
            >
              🃏 特典小卡 $450
            </button>
            <button
              type="button"
              onClick={() =>
                applyQuickPreset({
                  g: "daily",
                  cat: "手搖飲甜點",
                  title: "草莓奶蓋烏龍少冰",
                  amt: 85,
                  stk: "boba",
                  note: "今日小確幸 🧋",
                })
              }
              className="text-xs font-bold px-2.5 py-1 rounded-full bg-[#FFF5D6] hover:bg-[#FFE9A8] text-[#4A3728] border border-[#4A3728] cursor-pointer"
            >
              🧋 手搖珍奶 $85
            </button>
            <button
              type="button"
              onClick={() =>
                applyQuickPreset({
                  g: "daily",
                  cat: "餐飲美食",
                  title: "健康舒肥雞胸便當",
                  amt: 135,
                  stk: "bento",
                  note: "省錢存演唱會基金！",
                })
              }
              className="text-xs font-bold px-2.5 py-1 rounded-full bg-[#FFE8E0] hover:bg-[#FFD6C8] text-[#4A3728] border border-[#4A3728] cursor-pointer"
            >
              🍱 美味便當 $135
            </button>
            <button
              type="button"
              onClick={() =>
                applyQuickPreset({
                  g: "income",
                  cat: "二手出卡回血",
                  title: "售出重複專輯小卡回血",
                  amt: 600,
                  stk: "coin",
                  note: "回血轉入演唱會存錢筒 💰",
                })
              }
              className="text-xs font-bold px-2.5 py-1 rounded-full bg-[#E4FBF0] hover:bg-[#C6F7DF] text-[#4A3728] border border-[#4A3728] cursor-pointer"
            >
              💰 出卡回血 +$600
            </button>
          </div>
        </div>

        <form onSubmit={handleFormSubmit} className="space-y-4">
          {/* Group Type Selector */}
          <div className="grid grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={() => handleGroupSwitch("idol")}
              className={`py-2.5 px-3 rounded-2xl border-2 border-[#4A3728] font-black text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                groupType === "idol"
                  ? "bg-[#FF6B9D] text-white shadow-[3px_3px_0px_#4A3728]"
                  : "bg-white text-[#4A3728]"
              }`}
            >
              🎤 追星消費
            </button>
            <button
              type="button"
              onClick={() => handleGroupSwitch("daily")}
              className={`py-2.5 px-3 rounded-2xl border-2 border-[#4A3728] font-black text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                groupType === "daily"
                  ? "bg-[#FFB84D] text-[#4A3728] shadow-[3px_3px_0px_#4A3728]"
                  : "bg-white text-[#4A3728]"
              }`}
            >
              🍱 日常生活
            </button>
            <button
              type="button"
              onClick={() => handleGroupSwitch("income")}
              className={`py-2.5 px-3 rounded-2xl border-2 border-[#4A3728] font-black text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                groupType === "income"
                  ? "bg-[#38C697] text-white shadow-[3px_3px_0px_#4A3728]"
                  : "bg-white text-[#4A3728]"
              }`}
            >
              💰 收入回血
            </button>
          </div>

          {/* Date & Amount Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-black text-[#4A3728] mb-1">
                📅 記帳日期
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-sm font-bold focus:outline-none focus:ring-2 focus:ring-[#FF6B9D]"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-black text-[#4A3728] mb-1">
                💵 金額 (NT$)
              </label>
              <input
                type="number"
                min="1"
                placeholder="例如：450"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-base font-bold text-[#FF5C8A] focus:outline-none focus:ring-2 focus:ring-[#FF6B9D]"
                required
              />
            </div>
          </div>

          {/* Category Pills */}
          <div>
            <label className="block text-xs font-black text-[#4A3728] mb-1.5">
              🏷️ 選擇分類標籤
            </label>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_MAP[groupType].map((c) => (
                <button
                  key={c.label}
                  type="button"
                  onClick={() => {
                    setCategory(c.label);
                    setSticker(c.sticker);
                  }}
                  className={`px-3 py-1.5 rounded-xl border-2 border-[#4A3728] text-xs font-bold cursor-pointer transition-all ${
                    category === c.label
                      ? "bg-[#FFF0B8] text-[#4A3728] shadow-[2px_2px_0px_#4A3728]"
                      : "bg-white text-[#8C7365]"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title & Sticker Picker */}
          <div>
            <label className="block text-xs font-black text-[#4A3728] mb-1">
              📝 項目名稱
            </label>
            <input
              type="text"
              placeholder="例如：預購正規三輯特典版 / 草莓鮮奶茶"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-[#FF6B9D]"
            />
          </div>

          {/* Hand-drawn Stamp Picker */}
          <div>
            <label className="block text-xs font-black text-[#4A3728] mb-1.5">
              🎨 選擇月曆手繪貼紙印章
            </label>
            <div className="flex flex-wrap gap-2 bg-[#FFF8EB] p-2.5 rounded-2xl border-2 border-dashed border-[#D8C2B0]">
              {STICKER_OPTIONS.map((stk) => (
                <button
                  key={stk.id}
                  type="button"
                  onClick={() => setSticker(stk.id)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl border-2 transition-all cursor-pointer ${
                    sticker === stk.id
                      ? "border-[#4A3728] bg-white shadow-[2px_2px_0px_#4A3728] scale-105"
                      : "border-transparent hover:border-[#D8C2B0] opacity-75"
                  }`}
                >
                  <span className="text-base">{stk.emoji}</span>
                  <span className="text-[11px] font-bold">{stk.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Handwritten Note */}
          <div>
            <label className="block text-xs font-black text-[#4A3728] mb-1">
              💌 手帳小備註（選填）
            </label>
            <input
              type="text"
              placeholder="寫下今天的心情或追星小筆記..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6B9D]"
            />
          </div>

          <div className="pt-2 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="sticker-btn-soft px-5 py-2.5 rounded-full bg-white text-sm font-bold text-[#4A3728]"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="sticker-btn px-6 py-2.5 rounded-full bg-[#FF5C8A] text-white text-sm font-black flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              {submitting ? "蓋章儲存中..." : "蓋章記帳！"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface ConcertGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    title: string;
    artist: string;
    venue: string;
    concertDate: string;
    targetAmount: number;
    allocatedAmount: number;
    seatZone: string;
    ticketColor: string;
    isPrimary: boolean;
    notes: string;
  }) => Promise<void>;
}

export function ConcertGoalModal({
  isOpen,
  onClose,
  onSubmit,
}: ConcertGoalModalProps) {
  const [title, setTitle] = useState("2026 世界巡迴台北小巨蛋演唱會");
  const [artist, setArtist] = useState("LUNA & STARLIGHT");
  const [venue, setVenue] = useState("台北小巨蛋 Taipei Arena");
  const [concertDate, setConcertDate] = useState("2026-12-20");
  const [targetAmount, setTargetAmount] = useState("12000");
  const [allocatedAmount, setAllocatedAmount] = useState("3000");
  const [seatZone, setSeatZone] = useState("VIP 搖滾A區第一排");
  const [ticketColor, setTicketColor] = useState("strawberry");
  const [isPrimary, setIsPrimary] = useState(true);
  const [notes, setNotes] = useState("門票 $6,800 + 手燈周邊 $3,200 + 應援住宿 $2,000");
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onSubmit({
        title,
        artist,
        venue,
        concertDate,
        targetAmount: Number(targetAmount) || 12000,
        allocatedAmount: Number(allocatedAmount) || 0,
        seatZone,
        ticketColor,
        isPrimary,
        notes,
      });
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#4A3728]/45 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="sketch-card relative w-full max-w-lg bg-[#FFFDF7] p-6 md:p-7 my-8 animate-stamp">
        <div
          className="washi-tape-yellow absolute -top-3.5 left-1/2 -translate-x-1/2 w-32 h-6 rounded-sm"
          style={{ transform: "translateX(-50%) rotate(2deg)" }}
        />

        <div className="flex items-center justify-between border-b-2 border-dashed border-[#E5D5C5] pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <HandDrawnSticker sticker="ticket" size={40} />
            <div>
              <h3 className="text-xl font-black text-[#4A3728]">
                🎫 建立演唱會存錢目標
              </h3>
              <p className="text-xs text-[#8C7365]">
                設計你的專屬手繪夢想門票，啟動星途存錢地圖！
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="sticker-btn w-9 h-9 rounded-full bg-[#FFE3EC] flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-black mb-1">
              🌟 演唱會名稱
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-black mb-1">
                🎤 偶像團體 / 藝人
              </label>
              <input
                type="text"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-black mb-1">
                🏟️ 演出場館
              </label>
              <input
                type="text"
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-black mb-1">
                📅 預計演出日期
              </label>
              <input
                type="date"
                value={concertDate}
                onChange={(e) => setConcertDate(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-sm font-bold"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-black mb-1">
                💺 目標座位區域
              </label>
              <input
                type="text"
                value={seatZone}
                onChange={(e) => setSeatZone(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-black mb-1">
                🎯 目標總金額 (NT$)
              </label>
              <input
                type="number"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-sm font-bold text-[#FF5C8A]"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-black mb-1">
                💎 初始已存基金 (NT$)
              </label>
              <input
                type="number"
                value={allocatedAmount}
                onChange={(e) => setAllocatedAmount(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-sm font-bold text-[#2BB58A]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-black mb-1">
              🎨 手繪門票配色主題
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: "strawberry", label: "草莓牛奶", bg: "#FFE3EC" },
                { id: "lavender", label: "紫丁香星", bg: "#EFE6FF" },
                { id: "mint", label: "薄荷蘇打", bg: "#E0FAF0" },
                { id: "butter", label: "奶油焦糖", bg: "#FFF3C4" },
              ].map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setTicketColor(c.id)}
                  style={{ backgroundColor: c.bg }}
                  className={`py-2 rounded-xl border-2 border-[#4A3728] text-xs font-black cursor-pointer ${
                    ticketColor === c.id
                      ? "shadow-[2px_2px_0px_#4A3728] scale-105"
                      : "opacity-70"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-black mb-1">
              📝 預算細項備註
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border-2 border-[#4A3728] bg-white text-sm"
            />
          </div>

          <label className="flex items-center gap-2 pt-1 cursor-pointer">
            <input
              type="checkbox"
              checked={isPrimary}
              onChange={(e) => setIsPrimary(e.target.checked)}
              className="w-4 h-4 accent-[#FF5C8A]"
            />
            <span className="text-xs font-black text-[#4A3728]">
              設為星途首頁「主要演唱會目標」
            </span>
          </label>

          <div className="pt-3 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="sticker-btn-soft px-5 py-2 rounded-full bg-white text-sm font-bold"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="sticker-btn px-6 py-2 rounded-full bg-[#FF5C8A] text-white text-sm font-black flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              {submitting ? "印製門票中..." : "建立夢想演唱會"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBudget: number;
  currentBaseSavings: number;
  onUpdateBudget: (monthlyBudget: number, baseSavings: number) => Promise<void>;
  onResetDemo: () => Promise<void>;
  onResetZero: () => Promise<void>;
}

export function BudgetSettingsModal({
  isOpen,
  onClose,
  currentBudget,
  currentBaseSavings,
  onUpdateBudget,
  onResetDemo,
  onResetZero,
}: BudgetModalProps) {
  const [budget, setBudget] = useState(String(currentBudget));
  const [savings, setSavings] = useState(String(currentBaseSavings));
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setBudget(String(currentBudget));
    setSavings(String(currentBaseSavings));
  }, [currentBudget, currentBaseSavings]);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onUpdateBudget(Number(budget) || 20000, Number(savings) || 0);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#4A3728]/45 backdrop-blur-xs p-4">
      <div className="sketch-card relative w-full max-w-md bg-[#FFFDF7] p-6 animate-stamp">
        <div
          className="washi-tape-mint absolute -top-3.5 left-1/2 -translate-x-1/2 w-28 h-6 rounded-sm"
          style={{ transform: "translateX(-50%) rotate(-2deg)" }}
        />

        <div className="flex items-center justify-between border-b-2 border-dashed border-[#E5D5C5] pb-3.5 mb-4">
          <div className="flex items-center gap-2">
            <HandDrawnSticker sticker="coin" size={36} />
            <h3 className="text-lg font-black text-[#4A3728]">
              👛 調整預算與金庫設定
            </h3>
          </div>
          <button
            onClick={onClose}
            className="sticker-btn w-8 h-8 rounded-full bg-[#FFE3EC] flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-black text-[#4A3728] mb-1">
              📊 本月消費預算上限 (NT$)
            </label>
            <input
              type="number"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-base font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-black text-[#4A3728] mb-1">
              🏦 基礎流動資金存款 (NT$)
            </label>
            <input
              type="number"
              value={savings}
              onChange={(e) => setSavings(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border-2 border-[#4A3728] bg-white font-mono-num text-base font-bold"
            />
            <p className="text-[11px] text-[#8C7365] mt-1">
              總流動資金 ＝ 基礎存款 ＋ 累計收入 － 累計支出
            </p>
          </div>

          <div className="bg-[#FFF6E5] p-3.5 rounded-2xl border-2 border-dashed border-[#D8C2B0] space-y-2">
            <div className="text-xs font-black text-[#4A3728]">
              🛠️ 快速切換展示資料模式：
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={async () => {
                  setLoading(true);
                  await onResetDemo();
                  setLoading(false);
                  onClose();
                }}
                className="sticker-btn-soft py-2 px-2.5 rounded-xl bg-[#FFE3EC] text-xs font-black text-[#4A3728]"
              >
                ✨ 豐富手繪範例模式
              </button>
              <button
                type="button"
                onClick={async () => {
                  setLoading(true);
                  await onResetZero();
                  setLoading(false);
                  onClose();
                }}
                className="sticker-btn-soft py-2 px-2.5 rounded-xl bg-white text-xs font-black text-[#4A3728]"
              >
                🔄 歸零初始狀態 ($0)
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="sticker-btn-soft px-4 py-2 rounded-full bg-white text-sm font-bold"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={loading}
              className="sticker-btn px-5 py-2 rounded-full bg-[#FF5C8A] text-white text-sm font-black"
            >
              儲存設定
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
